class ShowApiDetails
{

	showApiDetails(mealId)
	{
		var requestURL3 = 'https://www.themealdb.com/api/json/v1/1/lookup.php?i='+mealId;
    	var request3 = new XMLHttpRequest();
    	request3.open('GET', requestURL3);
    	request3.responseType = 'json';

    	request3.onload = function () 
    	{
          var i = 1;
          var j = 1;
      		var data3 = request3.response;
      		var mealName = data3['meals'][0]['strMeal'];
      		var mealImage = data3['meals'][0]['strMealThumb'];
      		var mealInstructions = data3['meals'][0]['strInstructions'];

          
          document.getElementById('thumbnailImage').src = mealImage;
          document.getElementById('showTitleFromApi').innerHTML = mealName;
          document.getElementById('articleInDetailsBloc').innerHTML += mealInstructions;
          //console.log(data3);

          var link = data3['meals']['0']['strYoutube'];
          var firstCut = link.substr(0, 24);
          var secondCut = "embed/"
          var thirdCut = link.substr(32);
          var fullLink = firstCut+secondCut+thirdCut;

          document.getElementById('articleTutorial').src = fullLink;

          while(i < 20)
          {
            var mealIngredients = data3['meals'][0]['strIngredient'+[i]];
            var mealIngredientsMeasure = data3['meals'][0]['strMeasure'+[j]];
            var requestURL4 = 'https://www.themealdb.com/images/ingredients/'+mealIngredients+'-Small.png';
            
            if (mealIngredients[i].value != "")
            {
              document.getElementById('articleIngredientsBloc').innerHTML += '<h5>' + '<img src="'+requestURL4+'"><figcaption> '+ mealIngredients+' : ' +mealIngredientsMeasure + '</figcaption></h5>';
              i++ ;
              j++;
            }
          }

      		//var mealIngredients = data3['meals'][0]['strIngredient'+[i]]; 
          //console.log(mealIngredients.length);
      		//console.log(mealName);
      		//console.log(mealInstructions);
    	    //console.log(requestURL4);
          //console.log(mealIngredients);

           //trunc = "abcdef".substr(0, 3) + "\u2026";
      }
    	request3.send();

	}

}