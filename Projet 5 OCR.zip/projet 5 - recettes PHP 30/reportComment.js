let reportBoxStatus = "closed";
function reportBox(rows2)
{
	console.log(rows2);
	switch(reportBoxStatus)
	{
	
		case 'closed' :

		reportButton = "reportButton"+rows2;
		cancelButton = "cancelReportBox"+rows2;
		
		document.getElementById(reportButton).style.display = "none";
		document.getElementById(cancelButton).style.display = "inline-block";
		document.getElementById(rows2).style.display = "inline-block";
		reportBoxStatus = "open";
		break;

		case 'open' :
		document.getElementById(reportButton).style.display = "inline-block";
		document.getElementById(cancelButton).style.display = "none";
		document.getElementById(rows2).style.display = "none";
		reportBoxStatus = "closed";
		break;
	}

}

function CancelReport(rows2)
{
	reportButton = "reportButton"+rows2;
	cancelButton = "cancelReportBox"+rows2;
	
	document.getElementById(rows2).style.display = "none";
	document.getElementById(reportButton).style.display = "inline-block";
	document.getElementById(cancelButton).style.display = "none";
}