//------------------------------------------------------------- AJAX GET API -------------------------------------------------------------
let mealId;
let i;

class AjaxGet
{
	ajaxGet() 
	{
	    var requestURL = 'https://www.themealdb.com/api/json/v1/1/filter.php?a=French';
	   	var request = new XMLHttpRequest();
	    request.open('GET', requestURL);
	    request.responseType = 'json';

	    request.onload = function () 
	    {
	      var data = request.response;
	 
	      for (i = 0; i < data['meals'].length; i++) 
	      {	
	      	//console.log(data['meals'][i]);
	      	let mealsName = data['meals'][i]['strMeal'];
	      	let mealsImage = data['meals'][i]['strMealThumb'];
	      	mealId = data['meals'][i]['idMeal'];
	        document.getElementById('seeAllItemsBox').innerHTML += '<figure id="itemBloc"><a href="../index.php?action=showMoreFromApi&mealId='+mealId+'"><img id="thumbnailImage"  src="'+ mealsImage +'"></a><figcaption>'+ mealsName + '</figcaption></figure>';
	      }
	    }
	    request.send();
	}	

	getInfo()
	{
		var requestURL2 = 'https://www.themealdb.com/api/json/v1/1/lookup.php?i='+mealId;
    	var request2 = new XMLHttpRequest();
    	request2.open('GET', requestURL2);
    	request2.responseType = 'json';

    	request2.onload = function () 
    	{
      		var data2 = request2.response;
      		var mealInstructions = data2['meals'][0]['strInstructions'];
      		console.log(data2);     		
      		//console.log(mealInstructions);
    	}
    	request2.send();
	}	
 }

var ajaxGet = new AjaxGet();
ajaxGet.ajaxGet();
