tinymce.init({

	selector: "textarea.tinymce",
	plugins: 'code image',
	toolbar: 'undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',

});