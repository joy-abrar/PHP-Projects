<?php
	//inclut les controlleurs au chargement de l'index
	require('controller/controller_user.php');
	require('controller/controller_admin.php');
	
	$controls_user = new Controls_User();
	$controls_admin = new Controls_Admin();

			// Si le bouton cliqué a une propriété "action"
	if (isset($_GET['action'])) 
	{
			// Si "l'action" a la valeur "login"
		if ($_GET['action'] == "login") 
		{
			$id = $_POST['identification'];
			$pass = $_POST['pass'];

			$encryptedPassword = base64_encode($pass);
			$pass = $encryptedPassword;

			$controls_admin -> login($id,$pass);
		}

		if ($_GET['action'] == "createAccount") 
		{
			$id = htmlspecialchars($_POST['identification']);
			$email = htmlspecialchars($_POST['email']);
			
			$pass1 = $_POST['pass1'];
			$pass2 = $_POST['pass2'];

			$code = $_POST['code'];


			$decryptedPassword1 = base64_encode($pass1);
			$pass1 = $decryptedPassword1;

			$decryptedPassword2 = base64_encode($pass2);
			$pass2 = $decryptedPassword2;

			$decryptedCode = base64_encode($code);
			$code = $decryptedCode;
			
			$controls_admin -> createAccount($id,$email,$pass1,$pass2, $code);
		}

		if ($_GET['action'] == "loggedIn") 
		{
			$username = $_GET['username'];
			$id= $_GET['id'];

			session_start();
			$_SESSION['userName'] = $username;
			$_SESSION['id'] = $id;
			$controls_admin -> loggedIn();
		}

		if ($_GET['action'] == "forgetPassword") 
		{
			$email = $_POST['email'];
			$code = $_POST['code'];
			$controls_admin -> emailCheck($email, $code);	
		}

		if ($_GET['action'] == "wrongEmailInserted") 
		{
			$email = $_POST['email'];
			$controls_admin -> wrongEmailInserted($email);	
		}

		if ($_GET['action'] == "resetPassword") 
		{
			$email = $_GET['email'];
			$controls_admin -> resetPassword($email);	
		}

		if ($_GET['action'] == "passwordChanged") 
		{
			$email = $_GET['email'];
			$password = $_POST['password'];
			$retypedPassword = $_POST['retypePassword'];

			$encryptedPassword1 = base64_encode($password);
			$password = $encryptedPassword1;

			$encryptedPassword2 = base64_encode($retypedPassword);
			$retypedPassword = $encryptedPassword2;
			
			if ($password == $retypedPassword) 
			{
				$controls_admin -> passwordChanged($email, $password);
			}

			else
			{
				header('location:index.php?action=resetPassword&email='.$email);
			}
		}
		
		if ($_GET['action'] == "goDashboard") 
		{
			$controls_admin -> goDashboard();
		}

		if ($_GET['action'] == "wrongLogin") 
		{
			$controls_user -> wrongLogin();
		}

		if ($_GET['action'] == "disconnect") 
		{
			$controls_admin -> disconnect();
		}

		if ($_GET['action'] == "terms") 
		{
			$controls_admin -> terms();
		}

		if ($_GET['action'] == "termsAccountCreating") 
		{
			$controls_admin -> termsAccountCreating();
		}

		if ($_GET['action'] == "messages") 
		{
			$controls_admin -> personalMessages();
		}

		if ($_GET['action'] == "showThisUserMessage") 
		{
			$selectedUser = $_GET['selectedUser'];
			$controls_admin -> showThisUserMessage($selectedUser);
		}
		

		if ($_GET['action'] == "sendThisMessage") 
		{
			$selectedUser = $_GET['selectedUser'];
			$message = htmlspecialchars($_POST['messageContent']);
			$controls_admin -> sendThisMessage($selectedUser, $message);
		}

		if ($_GET['action'] == "globalChat") 
		{
			$controls_admin -> globalChat();
		}

		if ($_GET['action'] == "contactAdmin") 
		{
			$controls_admin -> contactAdmin();
		}

		if ($_GET['action'] == "settings") 
		{
			$controls_admin -> settings();
		}

		if ($_GET['action'] == "updateMyAccount") 
		{
			session_start();
			$username = $_POST['identifiant'];
			$email = $_POST['email'];
			$pass1 = $_POST['pass1'];
			$pass2 = $_POST['pass2'];
			$code = $_POST['code'];
			
			$encryptedPassword1 = base64_encode($pass1);
			$pass1 = $encryptedPassword1;

			$encryptedPassword2 = base64_encode($pass2);
			$pass2 = $encryptedPassword2;

			$encryptedCode = base64_encode($code);
			$code = $encryptedCode;

			$controls_admin -> updateMyAccount($username,$email,$pass1,$pass2,$code);
		}

		if ($_GET['action'] == "deleteMyAccount") 
		{
			session_start();
			$id = $_SESSION['id'];
			$password = $_POST['password'];
			$controls_admin -> deleteMyAccount($id,$password);
		}
		
		

		if ($_GET['action'] == "entree") 
		{
			$controls_admin -> entree();
		}

		if ($_GET['action'] == "plat") 
		{
			$controls_admin -> plat();
		}

		if ($_GET['action'] == "dessert") 
		{
			$controls_admin -> dessert();
		}

		if ($_GET['action'] == "ajouterItem") 
		{
			$controls_admin -> ajouterItem();
		}

		if ($_GET['action'] == "addThisItem") 
		{
			$title = $_POST['title'];
			$recipeImage = $_POST['recipeImage'];
			$description = $_POST['description'];
			$category = $_POST['category'];
			
			if ($recipeImage == null)
			{
				$recipeImage = "null";
			}
			
			$controls_admin -> addThisItem($title,$recipeImage,$description,$category);
		}

		if ($_GET['action'] == "myRecipes") 
		{
			$controls_admin -> myRecipes();
		}
		

		if ($_GET['action'] == "seeMoreOfThis") 
		{
			$id = $_GET['id'];
			$category = $_GET['category'];
			$controls_admin -> seeMoreOfThis($id,$category);
		}
		
		if ($_GET['action'] == "editMyOwnArticle")		
		{
			$id = $_GET['id'];
			$category = $_GET['category'];
			$controls_admin -> editMyOwnArticle($id,$category);	
		}

		if ($_GET['action'] == "editMyOwnArticleFromDashboard")		
		{
			$id = $_GET['id'];
			$category = $_GET['category'];
			$controls_admin -> editMyOwnArticleFromDashboard($id,$category);	
		}

		if ($_GET['action'] == "goToMyRecipes") 
		{
			$controls_admin -> goToMyRecipes();
		}
		

		if ($_GET['action'] == "updateMyOwnArticle")		
		{
			$id = $_GET['id'];
			$title = $_POST['title'];
			$recipeImage = $_POST['recipeImage'];
			$description = $_POST['description'];
			$category = $_POST['category'];			
			$controls_admin -> updateMyOwnArticle($id,$title,$recipeImage,$description,$category);
		}

		if ($_GET['action'] == "updateMyOwnArticleFromDashboard")		
		{
			$id = $_GET['id'];
			$title = $_POST['title'];
			$recipeImage = $_POST['recipeImage'];
			$description = $_POST['description'];
			$category = $_POST['category'];			
			$controls_admin -> updateMyOwnArticleFromDashboard($id,$title,$recipeImage,$description,$category);
		}


		if ($_GET['action'] == "publishThisComment")		
		{
			$articleId = $_GET['id'];
			$category = $_GET['category'];
			$comment = $_POST['comment'];
			$controls_admin -> publishThisComment($articleId,$comment,$category);
		}

		if ($_GET['action'] == "deleteThisComment") 
		{
			$articleId = $_GET['id'];
			$category = $_GET['category'];
			$commentId = $_GET['commentId'];
			$controls_admin -> deleteThisComment($articleId,$category,$commentId);
		}

		if ($_GET['action'] == "sendReport") 
		{
			$commentId = $_GET['commentId'];
			$reportMessage = $_POST['reportReason'];
			$id = $_GET['id'];
			$category = $_GET['category'];
			$controls_admin -> sendReport($commentId,$reportMessage,$id,$category);
		}
		

		if ($_GET['action'] == "deleteMyOwnArticle")		
		{
			$id = $_GET['id'];
			$category = $_GET['category'];
			$controls_admin -> deleteMyOwnArticle($id,$category);
		}

		if ($_GET['action'] == "deleteMyOwnArticleFromDashboard")		
		{
			$id = $_GET['id'];
			$category = $_GET['category'];
			$controls_admin -> deleteMyOwnArticle($id,$category);
		}		

		if ($_GET['action'] == "ourMenu") 
		{
			$controls_admin -> ourMenu();
		}		

		if ($_GET['action'] == "showMoreFromApi") 
		{
			$mealId = $_GET['mealId'];
			$controls_admin -> showMoreFromApi($mealId);
		}

		if ($_GET['action'] == "usersAccountsManagements") 
		{
			$controls_admin -> usersAccountsManagements();
		}

		if ($_GET['action'] == "editThisUserAccountAsAdmin") 
		{
			$userId = $_GET['userId'];
			$controls_admin -> editThisUserAccountAsAdmin($userId);
		}

		if ($_GET['action'] == "updateThisUserInformationAsAdmin") 
		{
			$userid = $_GET['id'];
			$username = $_POST['username'];
			$userpassword = $_POST['password'];
			$useremail = $_POST['email'];
			$userCode = $_POST['code'];
			$controls_admin -> updateThisUserInformationAsAdmin($userid, $username, $userpassword, $useremail, $userCode);
		}

		if ($_GET['action'] == "deleteThisUserAccountAsAdmin") 
		{
			$userid = $_GET['userId'];
			$controls_admin -> deleteThisUserAccountAsAdmin($userid);
		}		

		if ($_GET['action'] == "sendMessageToAdmin") 
		{
			session_start();
			$id = $_SESSION['id'];
			$username = $_SESSION['userName'];
			$messageto = "admin";
			$message = htmlspecialchars( $_POST['message']);
			$controls_admin -> sendMessageToAdmin($id, $username, $message, $messageto);
		}

		if ($_GET['action'] == "sendMessageToUser") 
		{
			session_start();
			$id = $_SESSION['id'];
			$username = $_SESSION['userName'];
			$messageto = "admin";
			$message = htmlspecialchars($_POST['message']);
			
			$controls_admin -> sendMessageToAdmin($id, $username, $message, $messageto);
		}

		if ($_GET['action'] == "usersListForRecipes") 
		{
			$controls_admin -> usersListForRecipes();
		}

		if ($_GET['action'] == "userRecipes") 
		{
			$listFor = $_GET['listFor'];
			$controls_admin -> userRecipes($listFor);
		}	

		if ($_GET['action'] == "editThisStarterArticleAsAdmin") 
		{
			$id = $_GET['id'];
			$controls_admin -> editThisStarterArticleAsAdmin($id);
		}

		if ($_GET['action'] == "deleteThisStarterArticleAsAdmin") 
		{
			$id = $_GET['id'];
			$controls_admin -> deleteThisStarterArticleAsAdmin($id);
		}

		if ($_GET['action'] == "editThisDishesArticleAsAdmin") 
		{
			$id = $_GET['id'];
			$controls_admin -> editThisDishesArticleAsAdmin($id);
		}

		if ($_GET['action'] == "deleteThisDishesArticleAsAdmin") 
		{
			$id = $_GET['id'];
			$controls_admin -> deleteThisDishesArticleAsAdmin($id);
		}

		if ($_GET['action'] == "editThisDessertArticleAsAdmin") 
		{
			$id = $_GET['id'];
			$controls_admin -> editThisDessertArticleAsAdmin($id);
		}

		if ($_GET['action'] == "deleteThisDessertArticleAsAdmin") 
		{
			$id = $_GET['id'];
			$controls_admin -> deleteThisDessertArticleAsAdmin($id);
		}

		if ($_GET['action'] == "updateUserArticleAsAdmin")		
		{
			$id = $_GET['id'];
			$title = $_POST['title'];
			$recipeImage = $_POST['recipeImage'];
			$description = $_POST['description'];
			$category = $_POST['category'];			
			$controls_admin -> updateUserArticleAsAdmin($id,$title,$recipeImage,$description,$category);
		}
	

		if ($_GET['action'] == "contactUsers") 
		{
			$controls_admin -> contactUsers();
		}

		if ($_GET['action'] == "reportedCommentsForAdmin") 
		{
			$controls_admin -> reportedCommentsForAdmin();
		}

		if ($_GET['action'] == "deleteThisReportedComment") 
		{
			$commentId = $_GET['commentId'];
			$controls_admin -> deleteThisReportedComment($commentId);
		}

		if ($_GET['action'] == "removeThisReport") 
		{
			$commentId = $_GET['commentId'];
			$controls_admin -> removeThisReport($commentId);
		}		

		if ($_GET['action'] == "showThisUserConversation") 
		{
			$selectedUser = $_GET['selectedUser'];
			$controls_admin -> showThisUserConversation($selectedUser);
		}		

		if ($_GET['action'] == "sendThisMessageToUser") 
		{
			$selectedUser = $_GET['selectedUser'];
			$message = $_POST['messageContent'];
			$controls_admin -> sendThisMessageToUser($selectedUser, $message);
		}	
	}

	else
	{
		
		$controls_user -> main();
	}

?>