<?php
	if ($_SESSION['sessionStatus'] == "loggedIn" && $_SESSION['userName'] != "admin") 
	{
?>	

	<!DOCTYPE html>
	<html>
	<head>
		<link rel="stylesheet" type="text/css" href="style.css">
		<title><?= $_SESSION['userName'] ?> - Messages </title>
		<meta content="width=device-width, initial-scale=1" name="viewport" />
		<link rel="icon" type="image/png" href="images/myRecipes.png" />
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
	</head>
	<body>
		<div id="topBorder">
				<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
				
				<a id="disconnetButton" href="index.php?action=disconnect">DISCONNECT</a>
				<div class="dropdown">
				  <a href="index.php?action=settings" class="dropbtn"><i class="fas fa-cog"></i></a>
				</div>
			</div>
			
			<div id="subtitleHome">
				<h4>Discover new recipes and cook it today for your closer !</h4>
			</div>

			<div id="menuHome">
				<a href="index.php?action=goDashboard" id="loggedUserName"><?php echo $_SESSION['userName']; ?></a>
				<hr>
				<a href="index.php?action=messages" id="loggedUserName">YOUR MESSAGES</a>
				<hr>
				<a href="index.php?action=globalChat" id="loggedUserName">GLOBAL CHAT</a>
				<hr>
				<a href="index.php?action=contactAdmin" id="loggedUserName">CONTACT</a>
				<hr>
			</div>


			<div id="messageUserListBox">
					
				<div id="messageUserList">
				<h2>User List</h2>
					<?php
						while ($rows = $getUserNames -> fetch()) 
						{
					?>
							<a href="index.php?action=showThisUserMessage&selectedUser=<?= $rows['username'] ?>" id="names"><button id="namesDesign"> <?= $rows['username']; ?></button> </a>	
					<?php
						}		
					?>
				</div>		
			
				<div id="showConversations">
					<?php
						while ($rows2 = $showThisUserMessage -> fetch()) 
						{
					?>
							<em><span id="usernameMessagesDesign"><?= $rows2['sender'] ?> said : </span><span><?= $rows2['message']  ?></span> </em>	<br><br>
					<?php
						}		
					?>
				</div>
			</div>

			<div >
				<form id="sendMessageForm" method="POST" action="index.php?action=sendThisMessage&selectedUser=<?= $selectedUser ?>">
					<input type="text" id="messageContent" name="messageContent" placeholder="Type Your Message Here..." maxlength="200">
					<input type="submit" id="submitMessage" name="submitMessage" value="SEND" >
				</form>

				<br><br><br>
				<center>
					<a href="index.php?action=goDashboard"><button id="returnButton">BACK</button></a>
				</center>
			</div>


	</body>
	</html>

<?php
	}

	else if ($_SESSION['sessionStatus'] == "loggedIn" && $_SESSION['userName'] == "admin") 
	{
	?>
		<!DOCTYPE html>
		<html>
		<head>
			<link rel="stylesheet" type="text/css" href="style.css">
			<title><?= $_SESSION['userName'] ?> - Messages </title>
			<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
		</head>
		<body>
			<div id="topBorder">
					<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
					
					<a id="disconnetButton" href="index.php?action=disconnect">DISCONNECT</a>
					<div class="dropdown">
					  <a href="index.php?action=settings" class="dropbtn"><i class="fas fa-cog"></i></a>
					</div>
				</div>
				
				<div id="subtitleHome">
					<h4>Discover new recipes and cook it today for your closer !</h4>
				</div>

				<div id="menuHome">
					<a href="index.php?action=goDashboard" id="loggedUserName"><?php echo $_SESSION['userName']; ?></a>
					<hr>
					<a href="index.php?action=messages" id="loggedUserName">YOUR MESSAGES</a>
					<hr>
					<a href="index.php?action=globalChat" id="loggedUserName">GLOBAL CHAT</a>
					<hr>
				</div>


				<div id="messageUserListBox">
						
					<div id="messageUserList">
					<h2>User List</h2>
						<?php
							while ($rows = $getUserNames -> fetch()) 
							{
						?>
								<a href="index.php?action=showThisUserConversation&selectedUser=<?= $rows['username'] ?>" id="names"><button id="namesDesign"> <?= $rows['username']; ?></button> </a>	
						<?php
							}		
						?>
					</div>		
				
					<div id="showConversations">
						<?php
							while ($rows2 = $showThisUserConversation -> fetch()) 
							{
						?>
								<em><span id="usernameMessagesDesign"><?= $rows2['messageFrom'] ?> said : </span><span><?= $rows2['message']  ?></span> </em>	<br><br>
						<?php
							}		
						?>
					</div>
				</div>

				<div >
					<form id="sendMessageForm" method="POST" action="index.php?action=sendThisMessageToUser&selectedUser=<?= $selectedUser ?>">
						<input type="text" id="messageContent" name="messageContent" placeholder="Type Your Message Here..." maxlength="200">
						<input type="submit" id="submitMessage" name="submitMessage" value="SEND" >
					</form>

					<br><br><br>
					<center>
						<a href="index.php?action=goDashboard"><button id="returnButton">BACK</button></a>
					</center>
				</div>


		</body>
		</html>
	<?php
	}

	else if ($_SESSION['sessionStatus'] != "loggedIn")
	{
		header("location: index.php");
	}
?>