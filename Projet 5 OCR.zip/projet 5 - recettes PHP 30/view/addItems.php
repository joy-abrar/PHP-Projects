<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Add Items</title>
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<link rel="icon" type="image/png" href="images/myRecipes.png" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
</head>
<body>
	<div id="topBorder">
		<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
		
		<a id="disconnetButton" href="index.php?action=disconnect">DISCONNECT</a>
		<div class="dropdown">
			<a href="index.php?action=settings" class="dropbtn"><i class="fas fa-cog"></i></a>
		</div>
	</div>
	
	<div id="subtitleHome">
		<h4>Discover new recipes and cook it today for your closer !</h4>
	</div>

	<div id="menuHome">
		<a href="index.php?action=goDashboard" id="loggedUserName"><?= $_SESSION['userName']; ?></a>
		<hr>
		<a href="index.php?action=messages" id="loggedUserName">YOUR MESSAGES</a>
		<hr>
		<a href="index.php?action=globalChat" id="loggedUserName">GLOBAL CHAT</a>
		<hr>
		<a href="index.php?action=contactAdmin" id="loggedUserName">CONTACT</a>
		<hr>
	</div>


	<div>
		<form method="POST" action="index.php?action=addThisItem" id="addItemBox">
			<span id="addItemTitle">TITLE OF RECIPE</span>
			<input id="addItemTitleBox" type="text" name="title" required>
			<span id="addItemTitle">LINK OF IMAGE RECIPE</span>
			<input id="addItemTitleBox" type="text" name="recipeImage">
			<center><h2>CHOOSE A CATEGORY</h2></center>
			<br>
			<div id="radioButtonBloc">
				<label>STARTER<input type="radio" name="category" value="entree"></label>
				<label>DISHES<input type="radio" name="category" value="plat"></label>
				<label>DESSERT<input type="radio" name="category" value="dessert"></label>
			</div>
			<span id="addItemDescription">RECIPE DETAILS</span>
			<textarea class="tinymce" name="description"></textarea>
			<br>
			<input id="addItemSubmitButton" type="submit" name="publish" value="PUBLISH">
			<br>
		</form>
		<br>
		<center>
				<a href="index.php?action=goDashboard"><button id="returnButton">BACK</button></a>
		</center>
	</div>

	<!-- *************************************FOOTER ******************************* -->
			<div id="footerPart">
				<div id="footerBloc">
						
						<div id="footerParts">
							<div id="footerAdministrationTitle">
								<h3 id="footerAdministration"><u><?= $_SESSION['userName'] ?></u></h3>	
								<div id="footerAdministrationContent">
									<a href="../index.php?action=disconnect" class="hyperlinkDecor">DISCONNECT</a>
									<a href="../index.php?action=terms" class="hyperlinkDecor">TERMS & CONDITIONS</a>
								</div>
							</div>	
						</div>

						
						<div id="footerParts">
							<div id="footerPlanTitle">
								<h3 id="footerPlan"><u>SITE PLAN</u></h3>
								<div id="footerPlanContent">
									<a href="../index.php?action=messages" class="hyperlinkDecor">MESSAGES</a>
									<a href="../index.php?action=globalChat" class="hyperlinkDecor">GLOBAL CHAT</a>
									<a href="../index.php?action=settings" class="hyperlinkDecor">SETTINGS</a>
								</div>
							</div>
						</div>


					<div id="footerParts">
						<div id="footerContactTitle">
							<h3 id="footerContact"><u>JOIN US</u></h3>
							<div id="footerContactContent">
								<a href="https://www.twitter.com" class="hyperlinkDecor">TWITTER</a>
								<a href="https://www.instagram.com" class="hyperlinkDecor">INSTAGRAM</a>
								<a href="https://www.facebook.com" class="hyperlinkDecor">FACEBOOK</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		<!------------------------------------------------ END FOOTER -------------------------------------->


	<script type="text/javascript" src="tinymce/js/jquery.min.js"></script>
	<script type="text/javascript" src="tinymce/plugin/tinymce/tinymce.min.js"></script>
	<script type="text/javascript" src="tinymce/plugin/tinymce/init-tinymce.js"></script>
</body>
</html>