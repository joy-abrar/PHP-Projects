<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title>Projet 5 - Food Recipe</title>
	<link rel="icon" type="image/png" href="images/myRecipes.png" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
</head>
<body>

	<div id="topBorder">
		<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
		
		<a href="#" onclick="switchButton()" id="createAccountButton">CREATE ACCOUNT</a>
		<a href="#" onclick="switchButton()" id="connexionButton">LOG IN</a>
	</div>


	<div id="mainBloc">
		
		<div id="homePageImage">
					<!-- Slideshow  -->
			<div class="slideshow-container">

			  <!-- Full-width images with number and caption text -->
			  <div class="mySlides fade">
			    <div class="numbertext">1 / 3</div>
			    <img id="homeImageParam" src="./images/img1.jpeg" style="width:100%">
			    <div class="text">Caption Text</div>
			  </div>

			  <div class="mySlides fade">
			    <div class="numbertext">2 / 3</div>
			    <img id="homeImageParam" src="./images/img2.jpeg" style="width:100%">
			    <div class="text">Caption Two</div>
			  </div>

			  <div class="mySlides fade">
			    <div class="numbertext">3 / 3</div>
			    <img id="homeImageParam" src="./images/img3.jpeg" style="width:100%">
			    <div class="text">Caption Three</div>
			  </div>

			</div>
			<br>
		</div>

		<form id="loginForm" method="POST" action="index.php?action=login"> 	
			<h2>CONNECT NOW !</h2>
			<span>Username :</span>
			<input id="loginInputBox" type="text" name="identification" value="" placeholder="Email ou Identifiant" required>
			<span>Password :</span>
			<input id="loginInputBox" type="password" name="pass" value="" placeholder="********" required>
			<input id="loginInputBox" type="checkbox" name="remindMe" value="">
			<span>Remind Me</span>
			<input id="loginButton" type="submit" name="connecter" value="CONNECTION">
			<a id="forgetPasswordLink" href="#" onclick="forgetPassword()">Forget Password ?</a>
		</form>

		<form id="forgetPasswordForm" method="POST" action="index.php?action=forgetPassword"> 	
			<h2>Forget Password ?</h2>
			<span>Email Address :</span>
			<input id="loginInputBox" type="email" name="email" placeholder="Enter Your Email Address" required>
			<span>Confidential Code :</span>
			<input id="loginInputBox" type="text" name="code" value="" placeholder="****" pattern="\d{4}" maxlength="4" required>
			<input id="loginButton" type="submit" name="connecter" value="NEXT">
			<a id="forgetPasswordLink" href="index.php" >Already An Account ? Connect Now</a>
		</form>

		<form id="createAccountForm" method="POST" action="index.php?action=createAccount"> 	
			<h2>CREATE AN ACCOUNT</h2>
			<span>Username :</span>
			<input id="loginInputBox" type="text" name="identification" value="" placeholder="Email Or Username" required>
			<span>Email Address :</span>
			<input id="loginInputBox" type="text" name="email" value="" placeholder="Email Or Username" required>
			<span>Password :</span>
			<input id="loginInputBox" type="password" name="pass1" value="" placeholder="********" required>
			<span>Confirm Password :</span>
			<input id="loginInputBox" type="password" name="pass2" value="" placeholder="********" required>
			<span>Confidential Code :</span>
			<input id="loginInputBox" type="text" name="code" value="" placeholder="****" pattern="\d{4}" maxlength="4" required>
			<a href="index.php?action=termsAccountCreating" class="hyperlinkDecor">TERMS & CONDITIONS</a>
			<input id="loginButton" type="submit" name="create" value="CREATE">
		</form>
	</div>

<script type="text/javascript" src="main.js"></script>
</body>
</html>