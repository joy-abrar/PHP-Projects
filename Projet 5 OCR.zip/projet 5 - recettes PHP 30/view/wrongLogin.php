<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<link rel="icon" type="image/png" href="images/myRecipes.png" />
	<title>Projet 5 - Food Recipe</title>
</head>
<body>

	<div id="topBorder">
		<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
		
		<a href="#" onclick="switchButton()" id="createAccountButton">CREATE ACCOUNT</a>
		<a href="#" onclick="switchButton()" id="connexionButton">LOG IN</a>
	</div>

	<div id="mainBloc">
			<div id="homePageImage">
					<!-- Slideshow container -->
			<div class="slideshow-container">

			  <!-- Full-width images with number and caption text -->
			  <div class="mySlides fade">
			    <div class="numbertext">1 / 3</div>
			    <img id="homeImageParam" src="./images/img1.jpeg" style="width:100%">
			    <div class="text">Caption Text</div>
			  </div>

			  <div class="mySlides fade">
			    <div class="numbertext">2 / 3</div>
			    <img id="homeImageParam" src="./images/img2.jpeg" style="width:100%">
			    <div class="text">Caption Two</div>
			  </div>

			  <div class="mySlides fade">
			    <div class="numbertext">3 / 3</div>
			    <img id="homeImageParam" src="./images/img3.jpeg" style="width:100%">
			    <div class="text">Caption Three</div>
			  </div>

			  <!-- Next and previous buttons -->
			  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
			  <a class="next" onclick="plusSlides(1)">&#10095;</a>
			</div>
			<br>

			<!-- The dots/circles -->
			<!--
			<div style="text-align:center">
			  <span class="dot" onclick="currentSlide(1)"></span>
			  <span class="dot" onclick="currentSlide(2)"></span>
			  <span class="dot" onclick="currentSlide(3)"></span>
			</div>
			-->
		</div>	
		
		<form id="loginForm" method="POST" action="index.php?action=login"> 	
			<h2>CONNECT NOW !</h2>
			<span>Username :</span>
			<input id="loginInputBox" type="text" name="identification" value="" placeholder="Email ou Identifiant" required>
			<span>Password :</span>
			<input id="loginInputBox" type="password" name="pass" value="" placeholder="********" required>
			<input id="loginInputBox" type="checkbox" name="remindMe" value="">
			<span style="color:red">Wrong Username Or Password Inserted !</span>
			<span style="color:red"> Please Retry.</span>
			<br>
			<span>Remember Me</span>
			<input id="loginButton" type="submit" name="connecter" value="CONNEXION">
			<a id="forgetPasswordLink" href="#">Forget Password ?</a>
		</form>

		<form id="forgetPasswordForm" method="POST" action="index.php?action=forgetPassword"> 	
			<h2>Forget Password ?</h2>
			<span>Email Address :</span>
			<input id="loginInputBox" type="email" name="email" placeholder="Enter Your Email Address" required>
			<input id="loginButton" type="submit" name="connecter" value="CONNECTION">
			<a id="forgetPasswordLink" href="index.php" >Already An Account ? Connect Now</a>
		</form>

		<form id="createAccountForm" method="POST" action="index.php?action=createAccount"> 	
			<h2>CREATE AN ACCOUNT</h2>
			<span>Email Address :</span>
			<input id="loginInputBox" type="text" name="identification" value="" placeholder="Email ou Identifiant" required>
			<span>Password :</span>
			<input id="loginInputBox" type="password" name="pass1" value="" placeholder="********" required>
			<span>Confirm Password :</span>
			<input id="loginInputBox" type="password" name="pass2" value="" placeholder="********" required>
			<input id="loginButton" type="submit" name="create" value="CREER">
		</form>
	</div>

<script type="text/javascript" src="main.js"></script>
</body>
</html>