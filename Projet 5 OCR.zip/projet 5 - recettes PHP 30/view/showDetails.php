<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title><?= $_SESSION['userName'] ?> - Show Recipe</title>
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<link rel="icon" type="image/png" href="images/myRecipes.png" />
	<link rel='stylesheet' href='https://use.fontawesome.com/releases/v5.7.0/css/all.css' integrity='sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ' crossorigin='anonymous'>
	<script type="text/javascript" src="reportComment.js"></script>
</head>
<body>
	<div id="topBorder">
		<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
		
		<a id="disconnetButton" href="index.php?action=disconnect">DISCONNECT</a>
		<div class="dropdown">
			<a href="index.php?action=settings" class="dropbtn"><i class="fas fa-cog"></i></a>
		</div>
	</div>
	
	<div id="subtitleHome">
		<h4>Discover new recipes and cook it today for your closer !</h4>
	</div>

	<div id="menuHome">
		<a href="index.php?action=goDashboard" id="loggedUserName"><?= $_SESSION['userName'] ?></a>
		<hr>
		<a href="index.php?action=messages" id="loggedUserName">YOUR MESSAGES</a>
		<hr>
		<a href="index.php?action=globalChat" id="loggedUserName">GLOBAL CHAT</a>
		<hr>
		<a href="index.php?action=contactAdmin" id="loggedUserName">CONTACT</a>
		<hr>
	</div>

	<?php
		while($rows = $seeMoreOfThis->fetch())
		{
			$id = $rows['id'];
			$title = $rows['title'];
			$recipeImage = $rows['recipeImage'];
			$recipe = $rows['recipe'];
			$publishingUser = $rows['publishingUser'];
		}
	?>

	<div>	
		<center>
			<h1><?= $title ?></h1>
			<?php
				if ($recipeImage != "null") 
				{
			?>
					<img id="thumbnailImage" src="<?= $recipeImage; ?>">
			<?php
				}
				else if ($recipeImage == "null") 
				{
			?>
					<img id="thumbnailImage" src="images/nonImage.png ?>">
			<?php	
				}
			?>
			<h5>Published By <?= $publishingUser ?>
			<?php 
				if($publishingUser == $_SESSION['userName']) 
				{ 
					echo '<a href="index.php?action=editMyOwnArticle&id='. $id .'&category='.$category.'">[EDIT]</a>';
					echo '<a href="index.php?action=deleteMyOwnArticle&id='. $id .'&category='.$category.'">[DELETE]</a>'; 
				} 
			?>
			</h5> 
		</center>	
			
			<div id="articleInDetailsBloc">
				<?= $recipe ?>	
			</div>
	</div>

	<div id="commentBloc">
		<h3><u>All Comments</u></h3>
		<br>
		<?php
			while($rows2 = $getComments->fetch())
			{
			$commentId = $rows2['id'];
		?>		
			<div>
				<h4><?= $rows2['username']?></h4>
				<p><?= $rows2['userComment'] ?></p>
				<h5>Posted On <?= $rows2['commentDate'] ?></h5>
				<?php
					if ($rows2['username'] == $_SESSION['userName']) 
					{
					 	echo '<a id="hyperLinkDeco" href=""><i class="fas fa-edit"></i></a>';
					 	echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
					 	echo '<a id="hyperLinkDeco" href="index.php?action=deleteThisComment&commentId='.$commentId.'&id='.$id.'&category='.$category.'"><i class="fas fa-trash-alt"></i></a>';
					 	echo '<br>';
					 } 
				?>
				<br>
				<br>
				<form style="display: none" id="<?= $rows2['id'] ?>" method="POST" action="index.php?action=sendReport&commentId=<?= $rows2['id'] ?>&id=<?= $id ?>&category=<?= $category ?>">
				   <br>
				   <input id="reportReasonBox" type="text" name="reportReason" placeholder="Please type the reason..." required>
					<br>
					<br>
					<input id="submitReportBox" type="submit" name="submitReport" value="SUBMIT">
				</form>
				<br>
				<br>
				<?php
					if ($rows2['report'] == "1") 
					{
				?>
						<em >REPORTED</em>		
				<?php
					}
					
					else
					{
				?>

				<a id="reportButton<?= $rows2['id'] ?>" onclick="reportBox(<?= $rows2['id'] ?>)" >REPORT</a>

				<?php
					}
				?>
				<a style="color: red" class="calcelReportButton" id="cancelReportBox<?= $rows2['id'] ?>" onclick="CancelReport(<?= $rows2['id'] ?>)">Cancel</a>
				<br>
				<hr id="commentHr">
				<br>

			</div>
		<?php
			}
		?>
		<br>
		<form method="POST" action="index.php?action=publishThisComment&id=<?= $id ?>&category=<?= $category ?>">
			<h4>Votre Commentaire</h4>
			<textarea name="comment" rows="10" cols="55" placeholder="Write Your Comment Here..."></textarea>
			<br><br>
			<input id="commentSubmitButton" type="submit" name="submit" value="PUBLISH">
		</form>
	</div>

	<div>
		<center>
			<a href="index.php?action=goDashboard"><button id="returnButton">BACK</button></a>
		</center>
	</div>

	<!-- *************************************FOOTER ******************************* -->
			<div id="footerPart">
				<div id="footerBloc">
						
						<div id="footerParts">
							<div id="footerAdministrationTitle">
								<h3 id="footerAdministration"><u><?= $_SESSION['userName'] ?></u></h3>	
								<div id="footerAdministrationContent">
									<a href="index.php?action=disconnect" class="hyperlinkDecor">DISCONNECT</a>
									<a href="index.php?action=terms" class="hyperlinkDecor">TERMS & CONDITIONS</a>
								</div>
							</div>	
						</div>

						
						<div id="footerParts">
							<div id="footerPlanTitle">
								<h3 id="footerPlan"><u>SITE PLAN</u></h3>
								<div id="footerPlanContent">
									<a href="index.php?action=messages" class="hyperlinkDecor">MESSAGES</a>
									<a href="index.php?action=globalChat" class="hyperlinkDecor">GLOBAL CHAT</a>
									<a href="index.php?action=settings" class="hyperlinkDecor">SETTINGS</a>
								</div>
							</div>
						</div>


					<div id="footerParts">
						<div id="footerContactTitle">
							<h3 id="footerContact"><u>JOIN US</u></h3>
							<div id="footerContactContent">
								<a href="https://www.twitter.com" class="hyperlinkDecor">TWITTER</a>
								<a href="https://www.instagram.com" class="hyperlinkDecor">INSTAGRAM</a>
								<a href="https://www.facebook.com" class="hyperlinkDecor">FACEBOOK</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		<!-------------------------------------------------END FOOTER -------------------------------------------->
</body>
</html>