<?php
	$email = $_GET['email'];
?>
<!DOCTYPE html>
<html>
<head>
	<link rel="icon" type="image/png" href="../images/myRecipes.png" />
	<link rel="stylesheet" type="text/css" href="../style.css">
	<title>Projet 5 - Food Recipe</title>
	<meta name="viewport" content="width=device-width, initial-scale=1" />
</head>
<body>

	<div id="topBorder">
		<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
		
	</div>


	<div id="mainBloc">
		
		<div id="homePageImage">
					<!-- Slideshow  -->
			<div class="slideshow-container">

			  <!-- Full-width images with number and caption text -->
			  <div class="mySlides fade">
			    <div class="numbertext">1 / 3</div>
			    <img id="homeImageParam" src="../images/img1.jpeg" style="width:100%">
			    <div class="text">Caption Text</div>
			  </div>

			  <div class="mySlides fade">
			    <div class="numbertext">2 / 3</div>
			    <img id="homeImageParam" src="../images/img2.jpeg" style="width:100%">
			    <div class="text">Caption Two</div>
			  </div>

			  <div class="mySlides fade">
			    <div class="numbertext">3 / 3</div>
			    <img id="homeImageParam" src="../images/img3.jpeg" style="width:100%">
			    <div class="text">Caption Three</div>
			  </div>

			</div>
			<br>

		</div>

		<form id="resetPasswordForm" method="POST" action="../index.php?action=passwordChanged&email=<?= $email ?>"> 	
			<h2>Reset Your Password ?</h2>
			<span>Type Your New Password :</span>
			<input id="loginInputBox" type="password" name="password" placeholder="Type Your New Password" required>
			<span>Retype Your New Password :</span>
			<input id="loginInputBox" type="password" name="retypePassword" placeholder="Retype Your New Password" required>
			<input id="loginButton" type="submit" name="reset" value="RESET">
			<a id="forgetPasswordLink" href="../index.php" >Already An Account ? Connect Now</a>
		</form>
	</div>

<script type="text/javascript" src="../main.js"></script>
</body>
</html>