<?php
	session_start();
	/* ------------------------------------ REGULAR USER LOGIN --------------------------------------- */
	if ($_SESSION['sessionStatus'] == "loggedIn" && $_SESSION['userName'] != "admin") 
	{
?>
		<!DOCTYPE html>
		<html>
		<head>
			<link rel="stylesheet" type="text/css" href="../style.css">
			<title><?= $_SESSION['userName']?> - Home</title>
			<meta content="width=device-width, initial-scale=1" name="viewport" />
			<link rel="icon" type="image/png" href="../images/myRecipes.png" />
			<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
		</head>
		<body>
			<!-- ************************ LE TITRE PRINCIPALE DU SITE *********************** -->
			<div id="topBorder">
				<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
				
				<a id="disconnetButton" href="../index.php?action=disconnect">DISCONNECT</a>
				<div class="dropdown">
				  <a href="../index.php?action=settings" class="dropbtn"><i class="fas fa-cog"></i></a>
				</div>
			</div>
			
			<div id="subtitleHome">
				<h4>Discover new recipes and cook it today for your closer !</h4>
			</div>

			<!-- ******************************* MENU NAV ******************************************** -->
			<div id="menuHome">
				<a href="../index.php?action=goDashboard" id="loggedUserName"><?php echo $_SESSION['userName']; ?></a>
				<hr>
				<a href="../index.php?action=messages" id="loggedUserName">YOUR MESSAGES</a>
				<hr>
				<a href="../index.php?action=globalChat" id="loggedUserName">GLOBAL CHAT</a>
				<hr>
				<a href="../index.php?action=contactAdmin" id="loggedUserName">CONTACT</a>
				<hr>
				
			</div>

			<!-- ****************************************LA LISTE DES CATEGORIES****************** -->
			<div id="userArticleMenu">
				<figure>
					<a href="../index.php?action=entree"><img id="menuImages" src="../images/entree.jpeg" alt="entree"></a>
					<figcaption id="figcap">STARTER</figcaption>
				</figure>

				<figure>
					<a href="../index.php?action=plat"><img id="menuImages" src="../images/plat.jpg" alt="plat"></a>
					<figcaption id="figcap">DISHES</figcaption>
				</figure>

				<figure>	
					<a href="../index.php?action=dessert"><img id="menuImages" src="../images/dessert.jpg" alt="dessert"></a>
					<figcaption id="figcap">DESSERT</figcaption>
				</figure>

			</div>
			<!-- ************************* GESTION DE MES PROPRES RECETTES ************************************* -->
			<div id="userArticleMenu">
				<figure>
					<a href="../index.php?action=ourMenu"><img id="menuImages" src="../images/ourMenu.png" alt="Our Menus"></a>
					<figcaption id="figcap">OUR MENUS</figcaption>
				</figure>	

				<figure>	
					<a href="../index.php?action=ajouterItem"><img id="menuImages" src="../images/addNewRecipe.png" alt="Add An Item"></a>
					<figcaption id="figcap">ADD A NEW RECIPE</figcaption>
				</figure>
				
				<figure>	
					<a href="../index.php?action=myRecipes"><img id="menuImages" src="../images/myRecipes.png" alt="My Recipes"></a>
					<figcaption id="figcap">MY RECIPES</figcaption>
				</figure>				
			</div>	

			<!-- *************************************FOOTER ******************************* -->
			<div id="footerPart">
				<div id="footerBloc">
						
						<div id="footerParts">
							<div id="footerAdministrationTitle">
								<h3 id="footerAdministration"><u><?= $_SESSION['userName'] ?></u></h3>	
								<div id="footerAdministrationContent">
									<a href="../index.php?action=disconnect" class="hyperlinkDecor">DISCONNECT</a>
									<a href="../index.php?action=terms" class="hyperlinkDecor">TERMS & CONDITIONS</a>
								</div>
							</div>	
						</div>

						
						<div id="footerParts">
							<div id="footerPlanTitle">
								<h3 id="footerPlan"><u>SITE PLAN</u></h3>
								<div id="footerPlanContent">
									<a href="../index.php?action=messages" class="hyperlinkDecor">MESSAGES</a>
									<a href="../index.php?action=globalChat" class="hyperlinkDecor">GLOBAL CHAT</a>
									<a href="../index.php?action=settings" class="hyperlinkDecor">SETTINGS</a>
								</div>
							</div>
						</div>


					<div id="footerParts">
						<div id="footerContactTitle">
							<h3 id="footerContact"><u>JOIN US</u></h3>
							<div id="footerContactContent">
								<a href="https://www.twitter.com" class="hyperlinkDecor">TWITTER</a>
								<a href="https://www.instagram.com" class="hyperlinkDecor">INSTAGRAM</a>
								<a href="https://www.facebook.com" class="hyperlinkDecor">FACEBOOK</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--------------------------------------------------- END FOOTER -------------------------------------->
		
		</body>
		</html>
	<?php
		}

/*---------------------------------------------- ADMIN LOGIN ----------------------------------------- */
	else if ($_SESSION['sessionStatus'] == "loggedIn" && $_SESSION['userName'] == "admin") 
	{
	?>

		<!DOCTYPE html>
		<html>
		<head>
			<link rel="stylesheet" type="text/css" href="../style.css">
			<title><?= $_SESSION['userName']?> - Home</title>
			<meta content="width=device-width, initial-scale=1" name="viewport" />
			<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
		</head>
		<body>
			<div id="topBorder">
				<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
				
				<a id="disconnetButton" href="../index.php?action=disconnect">DISCONNECT</a>
				<div class="dropdown">
				  <a href="../index.php?action=settings" class="dropbtn"><i class="fas fa-cog"></i></a>
				</div>
			</div>
			
			<div id="subtitleHome">
				<h4>Discover new recipes and cook it today for your closer !</h4>
			</div>

			<div id="menuHome">
				<a href="../index.php?action=goDashboard" id="loggedUserName"><?php echo $_SESSION['userName']; ?></a>
				<hr>
				<a href="../index.php?action=messages" id="loggedUserName">YOUR MESSAGES</a>
				<hr>
				<a href="../index.php?action=globalChat" id="loggedUserName">GLOBAL CHAT</a>
				<hr>
				
			</div>

			<!-- ************************ TABLEAU DE BORD TANT QU'ADMINISTRATEUR ********************** -->
			<div id="userArticleMenu">
				<figure>
					<a href="../index.php?action=usersAccountsManagements"><img id="menuImages" src="../images/users_management.png" alt="users accounts managements"></a>
					<figcaption id="figcap">USERS ACCOUNTS MANAGEMENTS</figcaption>
				</figure>

				<figure>
					<a href="../index.php?action=usersListForRecipes"><img id="menuImages" src="../images/users_articles.png" alt="users recipes"></a>
					<figcaption id="figcap">USERS RECIPES</figcaption>
				</figure>

				<figure>	
					<a href="../index.php?action=contactUsers"><img id="menuImages" src="../images/messages.png" alt="users messages"></a>
					<figcaption id="figcap">USERS MESSAGES</figcaption>
				</figure>

				<figure>	
					<a href="../index.php?action=reportedCommentsForAdmin"><img id="menuImages" src="../images/reportedComments.png" alt="reported comments"></a>
					<figcaption id="figcap">USERS REPORTS</figcaption>
				</figure>				

			</div>

			<!-- *************************************FOOTER ******************************* -->
			<br><br><br><br><br><br>
			<div id="footerPart">
				<div id="footerBloc">
						
						<div id="footerParts">
							<div id="footerAdministrationTitle">
								<h3 id="footerAdministration"><u><?= $_SESSION['userName'] ?></u></h3>	
								<div id="footerAdministrationContent">
									<a href="../index.php?action=disconnect" class="hyperlinkDecor">DISCONNECT</a>
								</div>
							</div>	
						</div>

						
						<div id="footerParts">
							<div id="footerPlanTitle">
								<h3 id="footerPlan"><u>SITE PLAN</u></h3>
								<div id="footerPlanContent">
									<a href="../index.php?action=messages" class="hyperlinkDecor">MESSAGES</a>
									<a href="../index.php?action=globalChat" class="hyperlinkDecor">GLOBAL CHAT</a>
									<a href="../index.php?action=settings" class="hyperlinkDecor">SETTINGS</a>
								</div>
							</div>
						</div>


					<div id="footerParts">
						<div id="footerContactTitle">
							<h3 id="footerContact"><u>JOIN US</u></h3>
							<div id="footerContactContent">
								<a href="https://www.twitter.com" class="hyperlinkDecor">TWITTER</a>
								<a href="https://www.instagram.com" class="hyperlinkDecor">INSTAGRAM</a>
								<a href="https://www.facebook.com" class="hyperlinkDecor">FACEBOOK</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!---------------------------------------------- END FOOTER ------------------------------------->
	
		</body>
		</html>
		
	<?php
	}
	/*-------------------------------------- IF NOT LOGGED IN -> GOTO LOGIN PAGE --------------------------- */
	else if ($_SESSION['sessionStatus'] != "loggedIn") 
	{
		header("location:../index.php");
	}
?>