<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title><?= $_SESSION['userName']?> - Home</title>
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<link rel="icon" type="image/png" href="images/myRecipes.png" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
</head>
<body>
	<div id="topBorder">
		<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
		
		<a id="disconnetButton" href="index.php?action=disconnect">DISCONNECT</a>
		<div class="dropdown">
		  <a href="index.php?action=settings" class="dropbtn"><i class="fas fa-cog"></i></a>
		</div>
	</div>
	
	<div id="subtitleHome">
		<h4>Discover new recipes and cook it today for your closer !</h4>
	</div>

	<div id="menuHome">
		<a href="index.php?action=goDashboard" id="loggedUserName"><?php echo $_SESSION['userName']; ?></a>
		<hr>
		<a href="index.php?action=messages" id="loggedUserName">YOUR MESSAGES</a>
		<hr>
		<a href="index.php?action=globalChat" id="loggedUserName">GLOBAL CHAT</a>
		<hr>
	</div>

			<!-- FORMULAIRE DE MODIFICATION D4UN COMPTE D'UTILISATEUR TANT QU'ADMIN -->
	<div id="userPublishingMenus">
				
		<div id="userPublishingStarters">
			<h2><i><u>USERS LIST</u></i></h2>
			<?php
				while ($rows = $editThisUserAccountAsAdmin -> fetch()) 
				{			
			?>		<div id="usersListsBoxParam">
						<form method="POST" action="index.php?action=updateThisUserInformationAsAdmin&id=<?= $rows['id'] ?>">
						<h3>Username : </h3>
						<input type="text" name="username" value="<?= $rows['username']; ?>">
						<h3>User Password : </h3>
						<input type="text" name="password" value="<?= $rows['password']; ?>">
						<h3>User Email : </h3>
						<input type="text" name="email" value="<?= $rows['email']; ?>">
						<h3>User Code : </h3>
						<input type="text" name="code" value="<?= $rows['code']; ?>">
						<br><br>
						<input type="submit" value="MODIFY">
						<br>
						<br>
						</form>
					</div>					
			<?php
				}
			?>	
		</div>
	</div>

	<div>
		<br><br>
		<center>
			<a href="index.php?action=goDashboard"><button id="returnButton">BACK</button></a>
		</center>
	</div>


</body>
</html>