$(document).ready(function(e)
{
	$.ajaxSetup(
		{
			cache: false
		});

	setInterval(function()
		{
			//------- CHARGEMENT DES MESSAGES DANS LA DIV DEPUIS BDD TOUS LES 500 ms------
			$('#chatlogs').load('logs.php');
			
			// ------------ AUTO SCROLL TO THE BOTTOM ---------------
			var element = document.getElementById("chatlogs");
    		element.scrollTop = element.scrollHeight;
		}
		,500);
});


function submitChat()
{
	//var msg = form1.msg.value;
	var msg = document.getElementById('message').value ;
	var name = document.getElementById('name').innerHTML;
	document.getElementById('message').value = "";
	var xmlhttp = new XMLHttpRequest();

	xmlhttp.onreadystatechange = function()
	{
		if (xmlhttp.readyState == 4 && xmlhttp.status == 200) 
		{
			document.getElementById('chatlogs').innerHTML += xmlhttp.responseText;		
		}
	}

	xmlhttp.open("GET" ,"insert.php?msg="+msg+"&name="+name , true);
	xmlhttp.send();

}
