<?php
	
	$msg = $_REQUEST["msg"];
	$name = $_REQUEST["name"];
	$connect = mysqli_connect ("localhost", "root", "", "projet5");

	$insert = "INSERT INTO globalChat SET username = '$name' , message = '$msg' ";

	mysqli_query($connect, $insert);
?>