<?php
	$connect = mysqli_connect ("localhost", "root", "", "projet5");

	$select = "SELECT * FROM globalChat ORDER BY id ASC";
	$response = mysqli_query($connect, $select);

	$count = mysqli_num_rows($response);

	
	if ($count > 0)
	{
		while ($rows = mysqli_fetch_array($response)) 
		{
?>
	 		<span id='showLogs'><h3><em id='showLogsName'><?= $rows['username']?></em> : <?= $rows['message']?></h3></span>
<?php		
		}
	}
?>