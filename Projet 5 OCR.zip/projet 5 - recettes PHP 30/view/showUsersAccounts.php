<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="style.css">
	<title><?= $_SESSION['userName']?> - Home</title>
	<meta content="width=device-width, initial-scale=1" name="viewport" />
	<link rel="icon" type="image/png" href="images/myRecipes.png" />
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
</head>
<body>
	<div id="topBorder">
		<h1 id="topBorderTitle">CHOOSE AND COOK TODAY !</h1>
		
		<a id="disconnetButton" href="index.php?action=disconnect">DISCONNECT</a>
		<div class="dropdown">
		  <a href="index.php?action=settings" class="dropbtn"><i class="fas fa-cog"></i></a>
		</div>
	</div>
	
	<div id="subtitleHome">
		<h4>Discover new recipes and cook it today for your closer !</h4>
	</div>

	<div id="menuHome">
		<a href="index.php?action=goDashboard" id="loggedUserName"><?php echo $_SESSION['userName']; ?></a>
		<hr>
		<a href="index.php?action=messages" id="loggedUserName">YOUR MESSAGES</a>
		<hr>
		<a href="index.php?action=globalChat" id="loggedUserName">GLOBAL CHAT</a>
		<hr>
		<?php
			if ($_SESSION['userName'] != "admin") 
			{
		?>
				<a href="index.php?action=contactAdmin" id="loggedUserName">CONTACT</a>
				<hr>
		<?php
			}
		?>
	</div>


	<div id="userPublishingMenus">
				
		<div id="userPublishingStarters">
			<h2><i><u>USERS LIST</u></i></h2>
			<?php
				while ($rows = $getAccountData -> fetch()) 
				{			
			?>		<div id="usersListsBoxParam">
						<h3><a id="textdeco" href="#"><?= $rows['username']; ?></a></h3>
						<h3>
							<a id="textdeco" href="index.php?action=editThisUserAccountAsAdmin&userId=<?= $rows['id'] ?>"><i class="fas fa-edit"></i></a>
							<a id="textdeco" href="index.php?action=deleteThisUserAccountAsAdmin&userId=<?= $rows['id'] ?>"><i class="fas fa-user-times"></i></a>
						</h3>
					</div>					
			<?php
				}
			?>	
		</div>
	</div>

	<div>
		<br><br>
		<center>
			<a href="index.php?action=goDashboard"><button id="returnButton">BACK</button></a>
		</center>
	</div>

	<!-- *************************************FOOTER ******************************* -->
			<div id="footerPart">
				<div id="footerBloc">
						
						<div id="footerParts">
							<div id="footerAdministrationTitle">
								<h3 id="footerAdministration"><u><?= $_SESSION['userName'] ?></u></h3>	
								<div id="footerAdministrationContent">
									<a href="index.php?action=disconnect" class="hyperlinkDecor">DISCONNECT</a>
								</div>
							</div>	
						</div>

						
						<div id="footerParts">
							<div id="footerPlanTitle">
								<h3 id="footerPlan"><u>SITE PLAN</u></h3>
								<div id="footerPlanContent">
									<a href="index.php?action=messages" class="hyperlinkDecor">MESSAGES</a>
									<a href="index.php?action=globalChat" class="hyperlinkDecor">GLOBAL CHAT</a>
									<a href="index.php?action=settings" class="hyperlinkDecor">SETTINGS</a>
								</div>
							</div>
						</div>


					<div id="footerParts">
						<div id="footerContactTitle">
							<h3 id="footerContact"><u>JOIN US</u></h3>
							<div id="footerContactContent">
								<a href="https://www.twitter.com" class="hyperlinkDecor">TWITTER</a>
								<a href="https://www.instagram.com" class="hyperlinkDecor">INSTAGRAM</a>
								<a href="https://www.facebook.com" class="hyperlinkDecor">FACEBOOK</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		<!--------------------------------------------------------- END FOOTER ----------------------------------------->

</body>
</html>