<?php
	require_once('model/Manager.php');

	class userManager extends Manager
	{

		public function emailCheck($email)
		{
			$db = $this->dbConnect();
			$check = $db -> prepare('SELECT email FROM users WHERE email = ?');
			$check ->execute(array($email));
			return $check;
		}

		public function codeCheck($code)
		{
			$db = $this->dbConnect();
			$check = $db -> prepare('SELECT code FROM users WHERE email = ?');
			$check ->execute(array($code));
			return $check;
		}

		public function updatePassword($email, $password)
		{
			$db = $this->dbConnect();
			$check = $db -> prepare('UPDATE users SET password = ? WHERE email = ?');
			$check ->execute(array($password, $email));
			return $check;
		}	

		public function showEntree()
		{
			$db = $this->dbConnect();
			$getItems = $db -> prepare('SELECT * FROM entree');
			$getItems ->execute(array());
			return $getItems;
		}

		public function showPlat()
		{
			$db = $this->dbConnect();
			$getItems = $db -> prepare('SELECT *FROM plat');
			$getItems ->execute(array());
			return $getItems;
		}		

		public function showDessert()
		{
			$db = $this->dbConnect();
			$getItems = $db -> prepare('SELECT *FROM dessert');
			$getItems ->execute(array());
			return $getItems;
		}

		public function addThisItem($title,$recipeImage,$description,$category)
		{
			session_start();
			$username = $_SESSION['userName'];

			if ($category == 'entree') 
			{
				$db = $this->dbConnect();
				$addItems = $db -> prepare('INSERT INTO entree(title,recipeImage,recipe,publishingUser) VALUES(?, ?, ?, ?) ');
				$addItems ->execute(array($title, $recipeImage, $description, $username));
			}

			if ($category == 'plat') 
			{
				$db = $this->dbConnect();
				$addItems = $db -> prepare('INSERT INTO plat(title,recipeImage,recipe,publishingUser) VALUES(?, ?, ?, ?) ');
				$addItems ->execute(array($title, $recipeImage, $description, $username));
			}

			if ($category == 'dessert') 
			{
				$db = $this->dbConnect();
				$addItems = $db -> prepare('INSERT INTO dessert(title,recipeImage,recipe,publishingUser) VALUES(?, ?, ?, ?) ');
				$addItems ->execute(array($title, $recipeImage, $description, $username));
			}
			
		}

		public function myStarterRecipes()
		{
			$username = $_SESSION['userName'];

			$db = $this->dbConnect();
			$getMyStarterRecipe = $db -> prepare('SELECT * FROM entree WHERE publishingUser = ?');
			$getMyStarterRecipe ->execute(array($username));
			return $getMyStarterRecipe;
		}

		public function myDishesRecipes()
		{
			$username = $_SESSION['userName'];

			$db = $this->dbConnect();
			$getMyDishesRecipe = $db -> prepare('SELECT * FROM plat WHERE publishingUser = ?');
			$getMyDishesRecipe ->execute(array($username));
			return $getMyDishesRecipe;
		}

		public function myDessertRecipes()
		{
			$username = $_SESSION['userName'];

			$db = $this->dbConnect();
			$getMyDessertRecipe = $db -> prepare('SELECT * FROM dessert WHERE publishingUser = ?');
			$getMyDessertRecipe ->execute(array($username));
			return $getMyDessertRecipe;
		}

		public function seeMoreOfThis($id,$category)
		{
			if ($category == "entree") 
			{
				$db = $this->dbConnect();
				$seeMoreOfThis = $db -> prepare('SELECT * FROM entree WHERE id = ? ');
				$seeMoreOfThis ->execute(array($id));
				return $seeMoreOfThis;  


			}

			if ($category == "plat") 
			{
				$db = $this->dbConnect();
				$seeMoreOfThis = $db -> prepare('SELECT * FROM plat WHERE id = ? ');
				$seeMoreOfThis ->execute(array($id));
				return $seeMoreOfThis; 
			}

			if ($category == "dessert") 
			{
				$db = $this->dbConnect();
				$seeMoreOfThis = $db -> prepare('SELECT * FROM dessert WHERE id = ? ');
				$seeMoreOfThis ->execute(array($id));
				return $seeMoreOfThis; 
			
			}					
		}

		public function getComments($id,$category)		
		{
			$db = $this->dbConnect();
			$getComments = $db -> prepare('SELECT * FROM comments WHERE articleId = ? ORDER BY id ASC');
			$getComments ->execute(array($id));
			return $getComments;
		}

		public function sendReport($commentId,$reportMessage)		
		{
			$reportStatus = "1";
			$db = $this->dbConnect();
			$submitReport = $db -> prepare('UPDATE comments SET report = ?, reportMessage = ?  WHERE id = ? ');
			$submitReport ->execute(array($reportStatus, $reportMessage, $commentId));
		}

		public function editMyOwnArticle($id,$category)
		{
			if ($category == "entree") 
			{
				$db = $this->dbConnect();
				$editMyOwnArticle = $db -> prepare('SELECT * FROM entree WHERE id = ? ');
				$editMyOwnArticle ->execute(array($id));
				return $editMyOwnArticle;
			}

			if ($category == "plat") 
			{
				$db = $this->dbConnect();
				$editMyOwnArticle = $db -> prepare('SELECT * FROM plat WHERE id = ? ');
				$editMyOwnArticle ->execute(array($id));
				return $editMyOwnArticle;
			}

			if ($category == "dessert") 
			{
				$db = $this->dbConnect();
				$editMyOwnArticle = $db -> prepare('SELECT * FROM dessert WHERE id = ? ');
				$editMyOwnArticle ->execute(array($id));
				return $editMyOwnArticle;
			}			
		}

		public function editMyOwnArticleFromDashboard($id,$category)
		{
			if ($category == "entree") 
			{
				$db = $this->dbConnect();
				$editMyOwnArticle = $db -> prepare('SELECT * FROM entree WHERE id = ? ');
				$editMyOwnArticle ->execute(array($id));
				return $editMyOwnArticle;
			}

			if ($category == "plat") 
			{
				$db = $this->dbConnect();
				$editMyOwnArticle = $db -> prepare('SELECT * FROM plat WHERE id = ? ');
				$editMyOwnArticle ->execute(array($id));
				return $editMyOwnArticle;
			}

			if ($category == "dessert") 
			{
				$db = $this->dbConnect();
				$editMyOwnArticle = $db -> prepare('SELECT * FROM dessert WHERE id = ? ');
				$editMyOwnArticle ->execute(array($id));
				return $editMyOwnArticle;
			}			
		}		


		public function updateMyOwnArticle($id,$title,$recipeImage,$description,$category)
		{
			session_start();
			$username = $_SESSION['userName'];

			if ($category == 'entree') 
			{
				$db = $this->dbConnect();
				$updateMyOwnArticle = $db -> prepare('UPDATE entree SET title = ?, recipeImage = ?, recipe = ? WHERE id = ?');
				$updateMyOwnArticle ->execute(array($title, $recipeImage, $description, $id));
			}

			if ($category == 'plat') 
			{
				$db = $this->dbConnect();
				$updateMyOwnArticle = $db -> prepare('UPDATE plat SET title = ?, recipeImage = ?, recipe = ? WHERE id = ?');
				$updateMyOwnArticle ->execute(array($title, $recipeImage, $description, $id));
			}

			if ($category == 'dessert') 
			{
				$db = $this->dbConnect();
				$updateMyOwnArticle = $db -> prepare('UPDATE dessert SET title = ?, recipeImage = ?, recipe = ? WHERE id = ?');
				$updateMyOwnArticle ->execute(array($title, $recipeImage, $description, $id));
			}	
		}

		public function updateMyOwnArticleFromDashboard($id,$title,$recipeImage,$description,$category)
		{
			session_start();
			$username = $_SESSION['userName'];

			if ($category == 'entree') 
			{
				$db = $this->dbConnect();
				$updateMyOwnArticle = $db -> prepare('UPDATE entree SET title = ?, recipeImage = ?, recipe = ? WHERE id = ?');
				$updateMyOwnArticle ->execute(array($title, $recipeImage, $description, $id));
			}

			if ($category == 'plat') 
			{
				$db = $this->dbConnect();
				$updateMyOwnArticle = $db -> prepare('UPDATE plat SET title = ?, recipeImage = ?, recipe = ? WHERE id = ?');
				$updateMyOwnArticle ->execute(array($title, $recipeImage, $description, $id));
			}

			if ($category == 'dessert') 
			{
				$db = $this->dbConnect();
				$updateMyOwnArticle = $db -> prepare('UPDATE dessert SET title = ?, recipeImage = ?, recipe = ? WHERE id = ?');
				$updateMyOwnArticle ->execute(array($title, $recipeImage, $description, $id));
			}	
		}

		public function publishThisComment($articleId,$comment)
		{
			$username = $_SESSION['userName'];
			$db = $this->dbConnect();
			$publishThisComment = $db -> prepare('INSERT INTO comments(username,userComment,articleId) VALUES(?, ?, ?)');
			$publishThisComment ->execute(array($username, $comment, $articleId));			
		}

		public function deleteThisComment($commentId)
		{
			$db = $this->dbConnect();
			$deleteThisComment = $db -> prepare('DELETE FROM comments WHERE id = ?');
			$deleteThisComment ->execute(array($commentId));			
		}

		public function deleteMyOwnArticle($id,$category)
		{
			if ($category == "entree") 
			{
				$db = $this->dbConnect();
				$deleteMyOwnArticle = $db -> prepare('DELETE FROM entree WHERE id = ? ');
				$deleteMyOwnArticle ->execute(array($id));
			}

			if ($category == "plat") 
			{
				$db = $this->dbConnect();
				$deleteMyOwnArticle = $db -> prepare('DELETE FROM plat WHERE id = ? ');
				$deleteMyOwnArticle ->execute(array($id));
			}

			if ($category == "dessert") 
			{
				$db = $this->dbConnect();
				$deleteMyOwnArticle = $db -> prepare('DELETE FROM dessert WHERE id = ? ');
				$deleteMyOwnArticle ->execute(array($id));
			}			
		}

		public function  personalMessages()
		{
			$db = $this -> dbConnect();
			$getPersonalMessages = $db -> prepare('SELECT username FROM users');
			$getPersonalMessages -> execute(array());
			return $getPersonalMessages;
		}

		public function  showThisUserMessage($selectedUser)
		{
			$sender = $_SESSION['userName'];

			$db = $this -> dbConnect();
			$showThisUserMessage = $db -> prepare('SELECT * FROM  messages WHERE sender = ? AND receiver = ? OR sender = ? AND receiver = ? ORDER BY id ASC ');
			$showThisUserMessage -> execute(array($sender ,$selectedUser, $selectedUser, $sender));
			return $showThisUserMessage;
		}

		public function  contactAdmin($messageFrom, $messageTo)
		{
			$messageFrom = $_SESSION['userName'];
			$db = $this -> dbConnect();
			$fetchedMessages = $db -> prepare('SELECT * FROM  adminmessages WHERE messageFrom = ? AND messageTo = ? OR messageFrom = ? AND messageTo = ? ORDER BY id ASC ');
			$fetchedMessages -> execute(array($messageFrom, $messageTo, $messageTo, $messageFrom));
			return $fetchedMessages;
		}		

		public function  sendThisMessage($selectedUser, $message)
		{
			$sender = $_SESSION['userName'];
			$receiver = $selectedUser;
			$message = $message;
			$db = $this -> dbConnect();
			$sendThisMessage = $db -> prepare('INSERT INTO  messages(sender, receiver, message) VALUES(?, ?, ?) ');
			$sendThisMessage -> execute(array($sender, $receiver,  $message));
			return $sendThisMessage;
		}


		public function settings($activeUser)
		{
			$db = $this->dbConnect();
			$getAccountInformation = $db -> prepare('SELECT * FROM users WHERE username = ?');
			$getAccountInformation ->execute(array($activeUser));
			return $getAccountInformation;
		}

		public function updateMyAccount($username,$email,$pass1,$pass2,$code)
		{
			$id = $_SESSION['id'];
			$db = $this->dbConnect();
			$updateMyAccount = $db -> prepare('UPDATE users SET username = ?, password = ?, email = ?, code = ? WHERE id = ?');
			$updateMyAccount ->execute(array($username, $pass1, $email,$code,$id));
		} 

		public function passwordCheck($id,$password)
		{
			$db = $this-> dbConnect();
			$passwordCheck = $db -> prepare('SELECT password FROM users WHERE id = ? ')	;
			$passwordCheck -> execute(array($id));
			return $passwordCheck;
		}

		public function deleteMyAccount($id,$password)
		{
			$db = $this-> dbConnect();
			$deleteMyAccount = $db -> prepare('DELETE FROM users WHERE id = ?');
			$deleteMyAccount ->execute(array($id));
		}		
		//-----------------------------------------------------------------------------------------------------------------------------------------------//

		public function postComment($sessionId, $username, $userComment) 
		{		 
			$db = $this->dbConnect();
			$sessionId = htmlspecialchars($sessionId);
			$usernameh = htmlspecialchars($username); 
			$userCommenth = htmlspecialchars($userComment);


			$comment = $db->prepare('INSERT INTO comments(articleId, username, comment) VALUES (?, ?, ?)');
			$affectedLines = $comment->execute(array($sessionId, $usernameh, $userCommenth));
			return $affectedLines;


			$numberOfComments = $db -> prepare('SELECT commentsNb FROM articles WHERE id = $sessionId');
			$affectedLines2 = $numberOfComments->execute(array($numberOfComments+1)); 
			return $affectedLines2;

		
			$insertNumberOfComments = $db->prepare('UPDATE articles SET (commentsNb) VALUES (?) WHERE id = $sessionId');
			$affectedLines3 = $insertNumberOfComments->execute(array($numberOfComments)); 
			return $affectedLines3;

		}

		public function controlMail($mail) // for accurate navigation in reading post pages (2/4) 
		{ 
			$db = $this->dbConnect();
			$mailCheck = $db->prepare('SELECT mail FROM account WHERE mail = ?');
			$mailVerif = $mailCheck->execute(array($mail)); 
			return $mailVerif;
		}

    	public function updateTempPwd($tempPwd, $mailtoAddress) 
    	{

	       	$db = $this->dbConnect();
	        $tempPassword = $db->prepare('UPDATE account SET password = ? WHERE mail = ?');
	        $randomInt = $tempPassword->execute(array($tempPwd, $mailtoAddress)); 
   		}

   		public function creatingArticleIntoDb($title, $para) 
		{
			$commentsNb = 0 ;
			$db = $this->dbConnect();
			$comment = $db->prepare('INSERT INTO articles(Title , Paragraph, commentsNb) VALUES (?, ?, ?)');
			$affectedLines = $comment->execute(array($title, $para, $commentsNb));
			return $affectedLines;
		}
		
		
		public function updatingArticleIntoDb($id , $givenArticleTitle, $givenArticleParagraph) 
		{
			$db = $this->dbConnect();
			$update = $db->prepare('UPDATE articles SET titre = ?, Paragraph = ? WHERE id = ?'); 
			$update->execute(array($givenArticleTitle, $givenArticleParagraph, $id));
		}

		public function usersAccountsManagements() 
		{
			$db = $this->dbConnect();
			$getAccountData = $db->prepare('SELECT * FROM users'); 
			$getAccountData->execute(array());
			return $getAccountData;
		}

		public function editThisUserAccountAsAdmin($userId) 
		{
			$db = $this->dbConnect();
			$getAccountData = $db->prepare('SELECT * FROM users WHERE id = ?'); 
			$getAccountData->execute(array($userId));
			return $getAccountData;
		}

		public function updateThisUserInformationAsAdmin($userid, $username, $userpassword, $useremail, $userCode) 
		{
			$db = $this->dbConnect();
			$editThisUserInformationAsAdmin = $db->prepare('UPDATE users SET username = ?, password = ?, email = ?, code = ? WHERE id = ?'); 
			$editThisUserInformationAsAdmin -> execute(array($username, $userpassword, $useremail, $userid, $userCode));
			return $editThisUserInformationAsAdmin;
		}	

		public function deleteThisUserAccountAsAdmin($userid) 
		{
			$db = $this->dbConnect();
			$deleteThisUserAccountAsAdmin = $db->prepare('DELETE FROM users WHERE id = ?'); 
			$deleteThisUserAccountAsAdmin -> execute(array($userid));
			return $deleteThisUserAccountAsAdmin;
		}	


		public function sendMessageToAdmin($id, $username, $message, $messageto) 
		{

			$db = $this->dbConnect();
			$sendMessageToAdmin = $db->prepare('INSERT INTO adminmessages(messageFrom, messageTo, message) VALUES(?, ?, ?)'); 
			$sendMessageToAdmin -> execute(array($username, $messageto, $message));
			return $sendMessageToAdmin;
		}	

		public function  usersListForRecipes()
		{
			$db = $this -> dbConnect();
			$getUserNames = $db -> prepare('SELECT username FROM users');
			$getUserNames -> execute(array());
			return $getUserNames;
		}	

		public function  userStarterRecipes($listFor)
		{
			$db = $this->dbConnect();
			$fetchedRecipes = $db -> prepare('SELECT * FROM entree WHERE publishingUser = ? ');
			$fetchedRecipes ->execute(array($listFor));
			return $fetchedRecipes;
				
		}

		public function  userDishesRecipes($listFor)
		{
			$db = $this->dbConnect();
			$fetchedRecipes = $db -> prepare('SELECT * FROM plat WHERE publishingUser = ? ');
			$fetchedRecipes ->execute(array($listFor));
			return $fetchedRecipes;
		}

		public function  userDessertRecipes($listFor)
		{
			$db = $this->dbConnect();
			$fetchedRecipes = $db -> prepare('SELECT * FROM dessert WHERE publishingUser = ? ');
			$fetchedRecipes ->execute(array($listFor));
			return $fetchedRecipes;
		}

		public function  editThisStarterArticleAsAdmin($id)
		{
			$db = $this->dbConnect();
			$fetchedResults = $db -> prepare('SELECT * FROM entree WHERE id = ? ');
			$fetchedResults ->execute(array($id));
			return $fetchedResults;
		}

		public function  deleteThisStarterArticleAsAdmin($id)
		{
			$db = $this->dbConnect();
			$fetchedResults = $db -> prepare('DELETE FROM entree WHERE id = ? ');
			$fetchedResults ->execute(array($id));
		}

			public function  editThisDishesArticleAsAdmin($id)
		{
			$db = $this->dbConnect();
			$fetchedResults = $db -> prepare('SELECT * FROM plat WHERE id = ? ');
			$fetchedResults ->execute(array($id));
			return $fetchedResults;
		}

		public function  deleteThisDishesArticleAsAdmin($id)
		{
			$db = $this->dbConnect();
			$fetchedResults = $db -> prepare('DELETE FROM plat WHERE id = ? ');
			$fetchedResults ->execute(array($id));
		}

		public function  editThisDessertArticleAsAdmin($id)
		{
			$db = $this->dbConnect();
			$fetchedResults = $db -> prepare('SELECT * FROM dessert WHERE id = ? ');
			$fetchedResults ->execute(array($id));
			return $fetchedResults;
		}

		public function  deleteThisDessertArticleAsAdmin($id)
		{
			$db = $this->dbConnect();
			$fetchedResults = $db -> prepare('DELETE FROM dessert WHERE id = ? ');
			$fetchedResults ->execute(array($id));
		}

		public function updateUserArticleAsAdmin($id,$title,$recipeImage,$description,$category)
		{
			session_start();
			$username = $_SESSION['userName'];

			if ($category == 'entree') 
			{
				$db = $this->dbConnect();
				$updateMyOwnArticle = $db -> prepare('UPDATE entree SET title = ?, recipeImage = ?, recipe = ? WHERE id = ?');
				$updateMyOwnArticle ->execute(array($title, $recipeImage, $description, $id));
			}

			if ($category == 'plat') 
			{
				$db = $this->dbConnect();
				$updateMyOwnArticle = $db -> prepare('UPDATE plat SET title = ?, recipeImage = ?, recipe = ? WHERE id = ?');
				$updateMyOwnArticle ->execute(array($title, $recipeImage, $description, $id));
			}

			if ($category == 'dessert') 
			{
				$db = $this->dbConnect();
				$updateMyOwnArticle = $db -> prepare('UPDATE dessert SET title = ?, recipeImage = ?, recipe = ? WHERE id = ?');
				$updateMyOwnArticle ->execute(array($title, $recipeImage, $description, $id));
			}	
		}

		public function  contactUsers()
		{
			$db = $this -> dbConnect();
			$getUserNames = $db -> prepare('SELECT username FROM users');
			$getUserNames -> execute(array());
			return $getUserNames;
		}

		public function  reportedCommentsForAdmin()
		{
			$reportStatus = "1";
			$db = $this -> dbConnect();
			$getReportedComments = $db -> prepare('SELECT * FROM comments WHERE report = ?');
			$getReportedComments -> execute(array($reportStatus));
			return $getReportedComments;
		}

		public function  deleteThisReportedComment($commentId)
		{
			
			$db = $this -> dbConnect();
			$deleteReportedComments = $db -> prepare('DELETE FROM comments WHERE id = ?');
			$deleteReportedComments -> execute(array($commentId));
		}	

		public function  removeThisReport($commentId)
		{
			$reportStatus = "0";
			$reportMessage = null;
			$db = $this -> dbConnect();
			$removeReportedComments = $db -> prepare('UPDATE comments SET report = ?, reportMessage = ? WHERE id = ?');
			$removeReportedComments -> execute(array($reportStatus, $reportMessage, $commentId));
		}		

		public function  showUserNames()
		{
			$db = $this -> dbConnect();
			$getPersonalMessages = $db -> prepare('SELECT username FROM users');
			$getPersonalMessages -> execute(array());
			return $getPersonalMessages;
		}

		public function  showThisUserConversation($selectedUser)
		{
			$sender = "admin";
			$db = $this -> dbConnect();
			$showThisUserConversation = $db -> prepare('SELECT * FROM  adminmessages WHERE messageFrom = ? AND messageTo = ? OR messageFrom = ? AND messageTo = ? ORDER BY id ASC ');
			$showThisUserConversation -> execute(array($sender ,$selectedUser, $selectedUser, $sender));
			return $showThisUserConversation;
		}

		public function  sendThisMessageToUser($selectedUser, $message)
		{
			$sender = $_SESSION['userName'];
			$receiver = $selectedUser;
			$message = $message;
			$db = $this -> dbConnect();
			$sendThisMessage = $db -> prepare('INSERT INTO  adminmessages(messageFrom, messageTo, message) VALUES(?, ?, ?) ');
			$sendThisMessage -> execute(array($sender, $receiver,  $message));
			return $sendThisMessage;
		}
	}


?>