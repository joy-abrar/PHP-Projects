<?php
	require_once('model/Manager.php');
	class loginManager extends Manager
	{
		public function getLogin($id,$pass) // for accurate navigation in reading post pages (2/4) 
		{


			$db = $this->dbConnect(); 
			$query = $db->prepare('SELECT * FROM users WHERE username = ? AND password = ?'); 
			$run = $query->execute(array($id, $pass));	
			$row = $query->fetch(PDO::FETCH_ASSOC);				
			$username = $row['username'];
			$password = $row['password'];

			$query2 = $db->prepare('SELECT id FROM users WHERE username = ?'); 
			$run2 = $query->execute(array($username));			
			$row2 = $query->fetch(PDO::FETCH_ASSOC);
			$idNumber = $row['id'];


			if ($run)
			{
				if ($id == $username && $pass == $password) 
				{
					header("location:index.php?action=loggedIn&username=$username&id=$idNumber");
				}
						
				else
				{
					$message = "<h1 style=>not logged in. try again!</h1>";
					header("location:index.php?action=wrongLogin");
				}
			}	

		}
	}


?>