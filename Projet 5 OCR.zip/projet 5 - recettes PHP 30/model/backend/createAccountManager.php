<?php
	require_once('model/Manager.php');

	class CreateAccountManager extends Manager
	{
		public function createAccount($id,$email,$pass1,$pass2,$code) 
		{ 
			if ($pass1 == $pass2) 
			{
				$db = $this->dbConnect();
				$createAccount = $db -> prepare('INSERT INTO users(username, password, email, code) VALUES(?, ?, ?, ?) ');
				$createAccount ->execute(array($id, $pass1, $email, $code));	
				header("location:index.php");
			}

			else if ($pass1 !== $pass2) 
			{
				echo "password did not match! Please try again !";
			}

		}
	}


?>