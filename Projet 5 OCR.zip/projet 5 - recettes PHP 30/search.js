
function search()
{	
  		let searchItem = document.getElementById('searchBox').value;

	    var requestURL = 'https://www.themealdb.com/api/json/v1/1/filter.php?a='+searchItem;
	   	var request = new XMLHttpRequest();
	    request.open('GET', requestURL);
	    request.responseType = 'json';

	    request.onload = function () 
	    {
	      var data = request.response;
	      document.getElementById('seeAllItemsBox').innerHTML ='';
	      for (i = 0; i < data['meals'].length; i++) 
	      {	
	      	//console.log(data['meals'][i]);
	      	let mealsName = data['meals'][i]['strMeal'];
	      	let mealsImage = data['meals'][i]['strMealThumb'];
	      	mealId = data['meals'][i]['idMeal'];
	        document.getElementById('seeAllItemsBox').innerHTML += '<figure id="itemBloc"><a href="../index.php?action=showMoreFromApi&mealId='+mealId+'"><img id="thumbnailImage"  src="'+ mealsImage +'"></a><figcaption>'+ mealsName + '</figcaption></figure>'; 
	        ajaxGet.getInfo();
	      }
	    }
	    
	    request.send();
	}