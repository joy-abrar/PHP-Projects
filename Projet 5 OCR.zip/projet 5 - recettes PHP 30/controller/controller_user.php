<?php

class Controls_User
{	

	function main()
	{

		require('view/home.php');
	}

	function wrongLogin()
	{
		require('view/wrongLogin.php');
	}


}

?>