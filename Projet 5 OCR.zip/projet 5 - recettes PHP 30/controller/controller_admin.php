<?php

require_once('model/frontend/userManager.php');


class Controls_Admin
{

	function login($id,$pass)
	{
		//$_SESSION['loginStatus'] = 0 ;
		//$userManager = new userManager();
		//$userManager -> login($id,$pass);
		require_once('model/backend/loginManager.php');
		$loginManager = new loginManager();
		$getLogin = $loginManager -> getLogin($id, $pass);
	}

	function loggedIn()
	{
		session_start();
		$_SESSION['sessionStatus'] = "loggedIn";
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			header("location:view/dashboard.php");
		}

		else
		{
			header("location:index.php");	
		}
		 	
	}

	function emailCheck($email,$code)
	{
		$userManager = new userManager();	 	
	 	$emailCheck = $userManager -> emailCheck($email);
	 	$codeCheck = $userManager -> codeCheck($code);

	 	$result = $emailCheck -> fetch(PDO::FETCH_ASSOC);

	 	$result2 = $codeCheck -> fetch(PDO::FETCH_ASSOC);

	 	if ($result > 0)
	 	{
	 		if ($result2 > 0) 
	 		{
	 			header('location: index.php?action=resetPassword&email='.$email);
	 		}

	 		else
	 		{
	 			header('location: index.php?action=wrongEmailInserted');
	 		}
	 	}

	 	else
	 	{
	 		header('location: index.php?action=wrongEmailInserted');
	 	}

	}

	function wrongEmailInserted($email)
	{
	 		header('location: view/wrongEmailInserted.php');

	}	

	function resetPassword($email)
	{
		header("location:view/resetPassword.php?email=".$email);
		 	
	}

	function passwordChanged($email, $password)
	{
		$userManager = new userManager();	 	
	 	$updatePassword = $userManager -> updatePassword($email, $password);
		header("location:index.php");
		 	
	}


	function goDashboard()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			header("location:view/dashboard.php");
		}

		else
		{
			header("location: index.php");
		}
		 	
	}


	function createAccount($id,$email,$pass1,$pass2, $code)
	{
		require_once('model/backend/createAccountManager.php');
		$createAccountManager = new CreateAccountManager();
		$getLogin = $createAccountManager -> createAccount($id,$email,$pass1,$pass2, $code);
	}

	 function deleteMyAccount($id,$password)
	 {
	 	$userManager = new userManager();	 	
	 	$getPassword = $userManager -> passwordCheck($id,$password);

	 	$passwordReceived = null;
	 	while($rows = $getPassword -> fetch())
		{
			$passwordReceived = $rows['password'];
		}

		if ($passwordReceived === $password) 
		{
			$userManager -> deleteMyAccount($id,$password); 
	 		header("location: index.php");
		}

		else
		{
			echo "Wrong password entered ! Try Again!";
		}
	 }

	function entree()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$category = "entree";
			$userManager = new userManager();
			$fetchedItems = $userManager -> showEntree();
			include("view/showItems.php");
		}

		else
		{
			header("location: ./index.php");	
		}
	}

	function plat()
	{	
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$category = "plat";
			$userManager = new userManager();
			$fetchedItems = $userManager -> showPlat();
			include("view/showItems.php");
		}

		else
		{
			header("location: ./index.php");	
		}
	}

	function dessert()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$category = "dessert";
			$userManager = new userManager();
			$fetchedItems = $userManager -> showDessert();
			include("view/showItems.php");
		}

		else
		{
			header("location: ./index.php");	
		}
	}

	function ourMenu()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$category = "ourMenu";
			header("location:view/ourMenu.php");
		}
		
		else
		{
			header("location: ./index.php");
		}
	}

	function ajouterItem()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			include("view/addItems.php");
		}
		
		else
		{
			header("location: ./index.php");
		}
	}

	function addThisItem($title,$recipeImage,$description,$category)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$userManager -> addThisItem($title,$recipeImage,$description,$category);
			header("location:index.php?action=goDashboard");
		}
			
		else
		{
			header("location: ./index.php");
		}
	}

	function myRecipes()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$getMyStarterRecipe = $userManager -> myStarterRecipes();
			$getMyDishesRecipe = $userManager -> myDishesRecipes();
			$getMyDessertRecipe = $userManager -> myDessertRecipes(); 
			include_once('view/showMyOwnRecipe.php');
		}
			
		else
		{
			header("location: ./index.php");
		}
	}


	function seeMoreOfThis($id,$category)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$seeMoreOfThis = $userManager -> seeMoreOfThis($id,$category);
			$getComments = $userManager -> getComments($id,$category);
			include('view/showDetails.php');
		}

		else
		{
			header("location: ./index.php");
		}		
	}

	function editMyOwnArticle($id,$category)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$editMyOwnArticle = $userManager -> editMyOwnArticle($id,$category);
			include('view/editMyOwnArticle.php');
		}

		else
		{
			header("location: ./index.php");
		}		
	}

	function editMyOwnArticleFromDashboard($id,$category)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$editMyOwnArticle = $userManager -> editMyOwnArticleFromDashboard($id,$category);
			include('view/editMyOwnArticleFromDashboard.php');
		}

		else
		{
			header("location: ./index.php");
		}		
	}

	function goToMyRecipes()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			header("location:index.php?action=myRecipes");
		}

		else
		{
			header("location: index.php");
		}
		 	
	}

	function updateMyOwnArticle($id,$title,$recipeImage,$description,$category)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$userManager -> updateMyOwnArticle($id,$title,$recipeImage,$description,$category);
			header("location:index.php?action=goDashboard");
		}
			
		else
		{
			header("location: ./index.php");
		}
	}

	function updateMyOwnArticleFromDashboard($id,$title,$recipeImage,$description,$category)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$userManager -> updateMyOwnArticleFromDashboard($id,$title,$recipeImage,$description,$category);
			header("location:index.php?action=myRecipes");
		}
			
		else
		{
			header("location: ./index.php");
		}
	}	


	function publishThisComment($articleId,$comment,$category)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$userManager -> publishThisComment($articleId,$comment);
			header('location:index.php?action=seeMoreOfThis&id='.$articleId.'&category='.$category);
			
		}
			
		else
		{
			header("location: ./index.php");
		}		
	}

	function deleteThisComment($articleId,$category,$commentId)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			echo $commentId;
			$userManager = new userManager();
			$userManager -> deleteThisComment($commentId);
			header('location:index.php?action=seeMoreOfThis&id='.$articleId.'&category='.$category);
			
		}

			
		else
		{
			header("location: ./index.php");
		}		
	}

	function sendReport($commentId,$reportMessage,$id,$category)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$userManager -> sendReport($commentId,$reportMessage);
			header('location:index.php?action=seeMoreOfThis&id='.$id.'&category='.$category);
			
		}

			
		else
		{
			header("location: ./index.php");
		}		
	}

	function deleteMyOwnArticle($id,$category)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$userManager -> deleteMyOwnArticle($id,$category);
			header("location:index.php?action=goDashboard");
		}

		else
		{
			header("location: ./index.php");
		}		
	}

	function disconnect()
	{
		session_start();
		$_SESSION['sessionStatus'] = "loggedOut";
		$_SESSION['userName'] = "";
		$_SESSION['id'] = "";
		if ($_SESSION['sessionStatus'] == "loggedOut") 
		{
			header("location: ./index.php");
		}
		
	}

	function terms()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			header("location:view/termsOfConditions.php");
		}

		else
		{
			header("location: ./index.php");
		}		
	}

	function termsAccountCreating()
	{
		header("location:view/termsOfConditionsForNonUsers.php");		
	}

	function personalMessages()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$getUserNames = $userManager -> personalMessages();

			include_once('view/messages.php');

			//header("location: view/messages.php");
		}

		else
		{
			header("location: index.php");
		}

	}

	function showThisUserMessage($selectedUser)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$getUserNames = $userManager -> personalMessages();
			$showThisUserMessage = $userManager -> showThisUserMessage($selectedUser);

			include_once('view/showConversation.php');
		}

		else
		{
			header("location: index.php");
		}	
	}

	function sendThisMessage($selectedUser, $message)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$sendThisMessage = $userManager -> sendThisMessage($selectedUser, $message);
			$getUserNames = $userManager -> personalMessages();
			$showThisUserMessage = $userManager -> showThisUserMessage($selectedUser);

			include_once('view/showConversation.php');
		}

		else
		{
			header("location: index.php");
		}	
	}


	function globalChat()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			header("location:view/globalChat/index.php");
		}

		else
		{
			header("location: index.php");
		}
	}

	function contactAdmin()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$messageFrom = $_SESSION['userName'];
			$messageTo = "admin" ;
			$userManager = new userManager();
			$fetcheedMessages = $userManager -> contactAdmin($messageFrom, $messageTo);
			include_once("view/contactAdmin.php");
		}

		else
		{
			header("location: index.php");
		}
	}

	function usersListForRecipes()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$fetchedUserNames = $userManager -> usersListForRecipes();
			
			include_once("view/usersListForRecipes.php");
		}

		else
		{
			header("location: index.php");
		}
	}	

	function userRecipes($listFor)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$fetchedStarterRecipes = $userManager -> userStarterRecipes($listFor);
			$fetchedDishesRecipes = $userManager ->userDishesRecipes($listFor);
			$fetchedDessertRecipes = $userManager ->userDessertRecipes($listFor);
			
			include_once("view/userRecipes.php");
		}

		else
		{
			header("location: index.php");
		}
	}

	function editThisStarterArticleAsAdmin($id)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$changeAsAdmin = $userManager -> editThisStarterArticleAsAdmin($id);
			include_once("view/changeAsAdmin.php");
		}

		else
		{
			header("location: index.php");
		}
	}	

	function deleteThisStarterArticleAsAdmin($id)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$changeAsAdmin = $userManager -> deleteThisStarterArticleAsAdmin($id);
			header("location:index.php?action=usersListForRecipes");
		}

		else
		{
			header("location: index.php");
		}
	}

	function editThisDishesArticleAsAdmin($id)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$changeAsAdmin = $userManager -> editThisDishesArticleAsAdmin($id);
			include_once("view/changeAsAdmin.php");
		}

		else
		{
			header("location: index.php");
		}
	}	

	function deleteThisDishesArticleAsAdmin($id)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$changeAsAdmin = $userManager -> deleteThisDishesArticleAsAdmin($id);
			header("location:index.php?action=usersListForRecipes");
		}

		else
		{
			header("location: index.php");
		}
	}		

	function editThisDessertArticleAsAdmin($id)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$changeAsAdmin = $userManager -> editThisDessertArticleAsAdmin($id);
			include_once("view/changeAsAdmin.php");
		}

		else
		{
			header("location: index.php");
		}
	}

	function deleteThisDessertArticleAsAdmin($id)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$changeAsAdmin = $userManager -> deleteThisDessertArticleAsAdmin($id);
			header("location:index.php?action=usersListForRecipes");
		}

		else
		{
			header("location: index.php");
		}
	}

	function updateUserArticleAsAdmin($id,$title,$recipeImage,$description,$category)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$userManager -> updateUserArticleAsAdmin($id,$title,$recipeImage,$description,$category);
			header("location:index.php?action=usersListForRecipes");
		}
			
		else
		{
			header("location: ./index.php");
		}
	}	

	function contactUsers()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$fetchedNames = $userManager -> contactUsers();
			
			include_once("view/contactAdmin.php");
		}

		else
		{
			header("location: index.php");
		}
	}	

	function reportedCommentsForAdmin()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$fetchedReports = $userManager -> reportedCommentsForAdmin();

			include_once("view/reportedComments.php");
		}

		else
		{
			header("location: index.php");
		}
	}		

	function deleteThisReportedComment($commentId)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$deleteThisComment = $userManager -> deleteThisReportedComment($commentId);

			header("location:index.php?action=reportedCommentsForAdmin");
		}

		else
		{
			header("location: index.php");
		}
	}	

	function removeThisReport($commentId)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$removeThisComment = $userManager -> removeThisReport($commentId);

			header("location:index.php?action=reportedCommentsForAdmin");
		}

		else
		{
			header("location: index.php");
		}
	}		

	function settings()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$activeUserName = $_SESSION['userName'];
			$userManager = new userManager();
			$fetchedItem = $userManager -> settings($activeUserName);
			while ($rows = $fetchedItem ->fetch()) 
			{
				$activeUserEmail = $rows['email'];
				$activeUserPassword = $rows['password'];
				header("location: view/settings.php?activeUserName=".$activeUserName."&activeUserPassword=".$activeUserPassword."&activeUserEmail=".$activeUserEmail);
			}	
		}

		else
		{
			header("location: index.php");
		}
	}	

	function updateMyAccount($username,$email,$pass1,$pass2,$code)
	{
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{		
			if ($pass1 == $pass2)
			{
				$userManager = new userManager();
				$userManager -> updateMyAccount($username,$email,$pass1,$pass2,$code);

				$_SESSION['userName'] = $username;
				header("location: ./index.php?action=settings");	
			}
		}

		else
		{
			header("location: ./index.php");
		}		
	}	


	function showMoreFromApi($mealId)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			header('location:view/showMoreFromApi.php?mealId='.$mealId);
		}

		else
		{
			header("location: ./index.php");
		}		
	}

	function usersAccountsManagements()
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$getAccountData = $userManager -> usersAccountsManagements();
			include_once('view/showUsersAccounts.php');
		}

		else
		{
			header("location: ./index.php");
		}		
	}

	function editThisUserAccountAsAdmin($userId)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$editThisUserAccountAsAdmin = $userManager -> editThisUserAccountAsAdmin($userId);
			include_once('view/editThisUserAccountAsAdmin.php');
		}

		else
		{
			header("location: ./index.php");
		}		
	}

	function updateThisUserInformationAsAdmin($userid, $username, $userpassword, $useremail, $userCode)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$updateThisUserInformationAsAdmin = $userManager -> updateThisUserInformationAsAdmin($userid, $username, $userpassword, $useremail, $userCode);
			header('location:index.php?action=usersAccountsManagements');
		}

		else
		{
			header("location: ./index.php");
		}		
	}

	function deleteThisUserAccountAsAdmin($userid)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$deleteThisUserAccountAsAdmin = $userManager -> deleteThisUserAccountAsAdmin($userid);
			header('location:index.php?action=usersAccountsManagements');
		}

		else
		{
			header("location: ./index.php");
		}		
	}	

	function sendMessageToAdmin($id, $username, $message, $messageto)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$sendMessageToAdmin = $userManager -> sendMessageToAdmin($id, $username, $message, $messageto);
			header('location:index.php?action=contactAdmin');
		}

		else
		{
			header("location: ./index.php");
		}		
	}	

	function showThisUserConversation($selectedUser)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$getUserNames = $userManager -> showUserNames();
			$showThisUserConversation = $userManager -> showThisUserConversation($selectedUser);
			include_once('view/showConversationForAdmin.php');
		}

		else
		{
			header("location: index.php");
		}	
	}	
	
	function sendThisMessageToUser($selectedUser, $message)
	{
		session_start();
		if ($_SESSION['sessionStatus'] == "loggedIn") 
		{
			$userManager = new userManager();
			$sendThisMessageToUser = $userManager -> sendThisMessageToUser($selectedUser, $message);
			$getUserNames = $userManager -> showUserNames();
			$showThisUserConversation = $userManager -> showThisUserConversation($selectedUser);

			include_once('view/showConversationForAdmin.php');
		}	
	}

}

?>