//----------------------------------------------------- CREATE/LOGIN DISPLAY HOMEPAGE-------------------------------------------------
let activeButton = "inscription";
let managementButtonStatus = "hidden";
let deleteAccountButtonStatus = "hidden";
function switchButton()
{	

	switch(activeButton)
	{
		case "inscription" :
		document.getElementById('createAccountButton').style.display = "none" ;
		document.getElementById('connexionButton').style.display = "inline-block" ;

		document.getElementById('loginForm').style.display = "none" ;
		document.getElementById('createAccountForm').style.display = "flex" ;

		document.getElementById('forgetPasswordForm').style.display = "none" ;
		
		activeButton = "connection";
		break;

		case "connection" :
		document.getElementById('connexionButton').style.display = "none" ;
		document.getElementById('createAccountButton').style.display = "inline-block" ;

		document.getElementById('loginForm').style.display = "flex" ;
		document.getElementById('createAccountForm').style.display = "none" ;

		document.getElementById('forgetPasswordForm').style.display = "none" ;

		activeButton = "inscription";
		break;		
	}
}

//----------------------------------------------USER ACCOUNT MANAGEMENT-------------------------------------------------------------------- 
function showAccountManagements()
{
	switch(managementButtonStatus)
	{
		case "hidden":
		document.getElementById('accManagementForm').style.display="inline-block";
		document.getElementById('deleteAccountForm').style.display="none";
		managementButtonStatus = "shown";
		break;

		case "shown":
		document.getElementById('accManagementForm').style.display="none";
		document.getElementById('deleteAccountForm').style.display="none";
		managementButtonStatus = "hidden"
		break;
	}
}

function deleteAccount()
{
	switch(deleteAccountButtonStatus)
	{
		case "hidden":
			document.getElementById('deleteAccountForm').style.display="flex";
			document.getElementById('accManagementForm').style.display="none";
			deleteAccountButtonStatus = "shown";
			break;

			case "shown":
			document.getElementById('deleteAccountForm').style.display="none";
			document.getElementById('accManagementForm').style.display="none";
			deleteAccountButtonStatus = "hidden";
			break;
	}
}

function forgetPassword()
{
	document.getElementById('forgetPasswordForm').style.display = "flex" ;
	document.getElementById('loginForm').style.display = "none" ;

}

//------------------------------------------------------ SLIDER HOMEPAGE------------------------------------------------------------

var slideIndex = 0;
showSlides();

function showSlides() {
  var i;
  var slides = document.getElementsByClassName("mySlides");
  for (i = 0; i < slides.length; i++) {
    slides[i].style.display = "none";
  }
  slideIndex++;
  if (slideIndex > slides.length) {slideIndex = 1}
  slides[slideIndex-1].style.display = "block";
  setTimeout(showSlides, 4000);
}

