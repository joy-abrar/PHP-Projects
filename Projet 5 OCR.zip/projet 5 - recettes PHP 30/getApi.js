//------------------------------------------------------------- FETCH API -------------------------------------------------------------

class GetApi
{
	startup()
	{


		fetch('https://www.themealdb.com/api/json/v1/1/filter.php?a=Indian')
		.then( function(response)
		{
			return response.json()
		})
		.then(function(data1)
		{
			var length1 = data1['meals'].length;
			
			for (var i = 0; i < length1; i++)
			{
				var mealId = data1['meals'][i]['idMeal'];
				var mealName = data1['meals'][i]['strMeal'];
				console.log("Name : " + mealName + ". ID : " + mealId );				
			

				fetch('https://www.themealdb.com/api/json/v1/1/lookup.php?i=' + mealId)
				.then( function(response)
				{
					return response.json()
				})
				.then(function(data2)
				{
					console.log(data2);
					var mealInstructions = data2['meals'][0]['strInstructions']; 	
					var mealImage = data2['meals'][0]['strMealThumb'];
					console.log(mealInstructions);
					console.log(mealImage);
				})
			} 
		})
	}
}

var getApi = new GetApi();
getApi.startup();