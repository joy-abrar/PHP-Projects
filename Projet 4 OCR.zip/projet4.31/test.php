<?php
if (isset($_GET['action']))
{
	if ($_GET['action']=='createArticleNow') 
	{
		var_dump($_GET['givenArticleTitle']);
		die();
		//$controls_admin -> createAnArticle();
	}
}

	if (isset($_GET['createArticleSubmitButton'])) 
		{
			var_dump($_GET['givenArticleTitle']);
			var_dump($_GET['givenArticleParagraph']);
			die();
		}
?>