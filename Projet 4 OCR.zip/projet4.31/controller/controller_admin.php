<?php

require_once('model/frontend/userManager.php');
require_once('model/frontend/postManager.php');
require_once('model/backend/loginManager.php');
require_once('controller/mailController.php');


class Controls_Admin
{

	function loggedIn()
	{
		
		header("location:view/adminLoggedIn/adminLoggedIn.php");
	}

	function forgetPswdPage()
	{
		header("location:view/forgetPassword/forgetPasswordPage.php");
	}

	function controlMail($mail)
	{
		$userManager = new userManager();
		$userInfo = $userManager->controlMail($mail);
		if ($userInfo) 
		{
		  $randomInt = rand(1000000, 999999999);
	      $tempPwd = hash('md5', $randomInt);
	      $userManager->updateTempPwd($tempPwd, $mail);
		  if ($userInfo) 
		  {
		  	$controls_mail = new Controls_Mail();
			$controls_mail -> sendTempPwd($mail, $randomInt);
		  }
	    }     
	    else 
	    {
          $_SESSION['info'] = 'Votre adresse est inconnue dans la base.<br>

          Cliquez pour revenir à la <a href="index.php?action=login">page de connexion</a>';
          echo "<h1>Sorry, Couldn't Verify Email From DataBase</h1>";
	    }	
	}

	function disconnect()
	{
		$loginManager = new loginManager();
		$getLogOut = $loginManager -> getLogOut();
	}

	function createAnArticle()
	{
		header("location:view/createArticle/createArticle.php");
	}

	function creatingArticleNow($title, $para)
	{
		$userManager = new userManager();
		$creatingArticleIntoDb = $userManager->creatingArticleIntoDb($title , $para);
		header("location:templates/posts/postPublished.php");
	}

	function editAnArticle()
	{
		$userManager = new userManager();
		$connect = $userManager -> editAnArticle();
		require("././view/editArticle/editArticle.php");
	}

	function viewMessages()
	{
		$userManager = new userManager();
		$viewMessages = $userManager -> viewMessages();
		require("././view/viewMessages/viewMessages.php");
	}

	function deleteMessage($messageId)
	{
		$userManager = new userManager();
		$deleteMessage = $userManager -> deleteMessage($messageId);
		header('location: index.php?action=viewMessages');
	}

	function editThisArticle($id,$title,$paragraph)
	{
		include('././view/updatingForm/updatingArticleForm.php');
	}

	function deleteThisArticle($id)
	{	
		include('././view/deletingArticleForm/deletingArticleForm.php');
		echo $id;
	}

	function deletingArticleFormConfirmed($id)
	{
		$id = $id;
		header('location:././view/deletingArticleFormConfirmed/deletingArticleFormConfirmed.php?id='.$id);
	}

	function deletingArticleFormDenied()
	{
		header('location:././view/billets.php');
	}

	function updateMyArticle($id, $givenArticleTitle, $givenArticleParagraph)
	{
		$id = $id;
		$givenArticleTitle = $givenArticleTitle ;
		$givenArticleParagraph = $givenArticleParagraph;
 		$userManager = new userManager();
		$updatingArticleIntoDb = $userManager->updatingArticleIntoDb($id , $givenArticleTitle, $givenArticleParagraph);
		header('location:././view/updatedArticle/updatedArticle.php?id='.$id . '&givenArticleTitle='.$givenArticleTitle.'&givenArticleParagraph='.$givenArticleParagraph);
	}

	function reportComments()
	{
		$userManager = new userManager();
		$commentsReported = $userManager->showReportedComments();
		require('././view/showReports/showReports.php');
	}

	function removeReport($id)
	{
		$userManager = new userManager();
		$removeSelectedReport = $userManager->removeThisReport($id);
		header('location:index.php?action=reportComments');
	}

	function deleteReport($id)
	{
		$userManager = new userManager();
		$deleteSelectedReport = $userManager->deleteThisReport($id);
		//require('././view/showReports/showReports.php');
		header('location:index.php?action=reportComments');
	}
}

?>