<?php

	$connection = mysqli_connect("localhost" , "root" , "" , "projet4");

?>