<?php
	$query = "SELECT * FROM articles";
	$run = mysqli_query($connect , $query);
	?>