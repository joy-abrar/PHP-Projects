<?php
	require_once('model/Manager.php');

	class userManager extends Manager
	{
		public function postComment($sessionId, $username, $userComment) 
		{		 
			$db = $this->dbConnect();
			$sessionId = htmlspecialchars($sessionId);
			$usernameh = htmlspecialchars($username); 
			$userCommenth = htmlspecialchars($userComment);
			$signalC = 0;

			$comment = $db->prepare('INSERT INTO comments(articleId, username, comment , signalc) VALUES (?, ?, ?, ?)');
			$affectedLines = $comment->execute(array($sessionId, $usernameh, $userCommenth, $signalC));
			//return $affectedLines;
		}


		public function updateCommentNumber($sessionId) 
		{		 
			$db = $this->dbConnect();
			$sessionId = htmlspecialchars($sessionId);
			$setValue = "2";

			$numberOfComments = $db -> prepare('UPDATE articles SET commentsNb = commentsNb+1 WHERE id = ?');
			$affectedLines2 = $numberOfComments->execute(array($sessionId)); 
			//return $affectedLines2;
		}

		public function controlMail($mail) // for accurate navigation in reading post pages (2/4) 
		{ 
			$db = $this->dbConnect();
			$mailCheck = $db->prepare('SELECT mail FROM account WHERE mail = ?');
			$mailVerif = $mailCheck->execute(array($mail)); 
			return $mailVerif;
		}

    	public function updateTempPwd($tempPwd, $mailtoAddress) 
    	{

	       	$db = $this->dbConnect();
	        $tempPassword = $db->prepare('UPDATE account SET password = ? WHERE mail = ?');
	        $randomInt = $tempPassword->execute(array($tempPwd, $mailtoAddress)); 
   		}

   		public function creatingArticleIntoDb($title, $para) 
		{
			$commentsNb = 0 ;
			$db = $this->dbConnect();
			$comment = $db->prepare('INSERT INTO articles(Title , Paragraph, commentsNb) VALUES (?, ?, ?)');
			$affectedLines = $comment->execute(array($title, $para, $commentsNb));
			return $affectedLines;
		}
		
		
		public function updatingArticleIntoDb($id , $givenArticleTitle, $givenArticleParagraph) 
		{
			$db = $this->dbConnect();
			$update = $db->prepare('UPDATE articles SET titre = ?, Paragraph = ? WHERE id = ?'); 
			$update->execute(array($givenArticleTitle, $givenArticleParagraph, $id));
		}

		public function signalComments($id) 
		{
			$db = $this->dbConnect();
			$update = $db->prepare('UPDATE comments SET signalc = 1 WHERE id = ?'); 
			$update->execute(array($id));
			return $update;
		}

		public function editAnArticle() 
		{
			$db = $this->dbConnect();
			$showArticles = $db -> prepare('SELECT * FROM articles');
			$showArticles->execute();
			return $showArticles;
		}

		public function viewMessages() 
		{
			$db = $this->dbConnect();
			$showMessages = $db -> prepare('SELECT * FROM messages');
			$showMessages->execute();
			return $showMessages;
		}
		
		public function deleteMessage($messageId) 
		{
			$db = $this->dbConnect();
			$deleteMessage = $db -> prepare('DELETE FROM messages WHERE id = ?');
			$deleteMessage->execute(array($messageId));
			return $deleteMessage;
		}


		public function showReportedComments() 
		{
			$signalcValue = 1 ;
			$db = $this->dbConnect();
			$showReports = $db->prepare('SELECT * FROM comments WHERE signalc = ?');
			$showReports->execute(array($signalcValue));
			return $showReports;
		}

		public function readMore($selectedId)
		{
			$db = $this->dbConnect();
			$query = $db->prepare("SELECT * FROM articles ORDER BY id DESC LIMIT 1");
			$query->execute(array());
			return $query;
		}

		public function readMoreComments($selectedId)
		{
			$db = $this->dbConnect();
			$query = $db->prepare("SELECT *FROM comments WHERE articleId = ?  ");
			$query->execute(array($selectedId));
			return $query;
		}

		public function readPost($selectedId)
		{
			$db = $this->dbConnect();
			$query = $db->prepare('SELECT * FROM articles WHERE id = ?');
			$query->execute(array($selectedId));
			return $query;
		}

		public function readPostComments($selectedId)
		{
			$db = $this->dbConnect();
			$query2 = $db->prepare('SELECT * FROM comments WHERE articleId = ? ORDER BY id DESC');
			$query2->execute(array($selectedId));
			return $query2;
		}

		public function removeThisReport($id)
		{
			$signalcValue = 0;
			$db = $this->dbConnect();
			$remove = $db->prepare('UPDATE comments SET signalc = ? WHERE id = ?');
			$remove->execute(array($signalcValue, $id));
			return $remove;
		}

		public function deleteThisReport($id)
		{
			$db = $this->dbConnect();
			$delete = $db->prepare('DELETE FROM comments WHERE id = ?');
			$delete->execute(array($id));
			return $delete;
		}

		public function postThisMessage($userMail,$userMessage) 
		{		 
			$db = $this->dbConnect();
			$userMail = htmlspecialchars($userMail); 
			$userMessage = htmlspecialchars($userMessage);
			
			$query = $db->prepare('INSERT INTO messages(userMail, userMessage) VALUES (?, ?)');
			$query->execute(array($userMail, $userMessage));
		}
		
	}


?>