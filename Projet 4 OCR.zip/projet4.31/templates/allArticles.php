<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>


<?php
	include('../model/databaseConnection.php');
	$query = "SELECT * FROM articles";
	$run = mysqli_query($connect , $query);
?>


<body>


		<?php
			while ($rows=mysqli_fetch_assoc($run)) 
			{
				$selectedId = $rows['id'];
				echo "allArticles.php " . $selectedId;
		?>
	<div id="recentArticles">
		<div id="articleView">
			<div id="firstArticle" name="firstArticle">
				<h3 id="firstArticleHeadTitle"><?php echo $rows['Title']; ?></h3>
				<hr id="firstArticleHeaderSeperationBloc">
				<p id="firstArticleParagraphe">	<?php echo $rows['Paragraph']; ?> </p>
				<hr id="firstArticleFooterSeperationBloc">
				<p id="firstArticleDate"> Publié le <?php echo $rows['date']; ?> </p>
				<a href="../index.php?action=viewMore&amp;selectedId= <?= $selectedId ?>">Voir Plus...</a>
			</div>		
		</div>
	</div>				
		<?php
			}
		?>

</body>
</html>