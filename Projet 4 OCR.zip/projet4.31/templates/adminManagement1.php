<?php
	include('../model/databaseConnection.php');
?>

<?php
		if (isset($_POST['createArt'])) 
		{
			header("location:./createArticle.php");
		}


		if (isset($_POST['createArticleSubmitButton'])) 
		{
			$givenTitle = $_POST['givenArticleTitle'];
			$givenPara = $_POST['givenArticleParagraph'];

			$inserting = "INSERT INTO articles(Title , Paragraph) VALUES ('$givenTitle' , '$givenPara')" ;

			$query = mysqli_query($connect , $inserting);
		
			if ($query) 
			{
				header("location:../templates/postPublished.php");
			}

			else
			{
				header("location:../templates/failedPublish.php");
			}
		}



		if (isset($_POST['editArt'])) 
		{
			header("location:./editArticle.php");	
		}

		
		if (isset($_POST['searchArticleButton'])) 
		{
			include('../model/connection.php');
			$articleForSearching = $_POST['searchArticleBox'];
			

			$query = "SELECT id , Title , Paragraph FROM articles WHERE Title = '$articleForSearching'";

			$run = mysqli_query($connection , $query);

			if (!$run) 
			{
				echo "Not Found !";
			}

			if ($run) 
			{
				$row = mysqli_fetch_row($run);
				//echo $row[0];
				$_SESSION['row0'] = $row[0] ;
				$_SESSION['row1'] = $row[1] ;
				$_SESSION['row2'] = $row[2] ;
				

				include('../templates/searchResult.php');
			}
		}
?>



