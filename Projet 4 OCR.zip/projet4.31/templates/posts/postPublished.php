<link rel="stylesheet" type="text/css" href="../../public/css/style.css">

<div>
	<center><h4 style="color:darkgreen;">Votre Article à été Publié !</h4></center>
	<center><h3 style="color:darkgreen;">Cliquez <a href="../../index.php?action=returnToArticles">ICI</a> pour retourner à la page des articles.</h2></center>

</div>