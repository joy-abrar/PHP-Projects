<link rel="stylesheet" type="text/css" href="../../public/css/style.css">

<div>
	<center><h4 style="color:red;">Votre Article n'a Pas Pu être Publié. veuillez réessayez ! </h4></center>
</div>