<form method="POST" action="index.php?action=postThisComment&amp;sessionId=<?= $sessionId; ?>">

		<center id="commentBoxParam">
			<h3>Ecrivez vos commentaires ici</h3>
			<h4>Nom d'utilisateur</h4>
			<input type="text" name="username" id="commentBoxUsernameParam">
	
			<h4>Commentaire</h4>
			<input type="text" name="userComment" id="commentBoxCommentParam">
		
			<br/><br/><br/>
			<center><input type="submit" name="postComment" id="commentBoxValidButtonParam" value="POSTER"></center>
		</center>

</form>