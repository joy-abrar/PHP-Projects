<html>
<head>
	<link rel="stylesheet" type="text/css" href="../public/css/style.css">
</head>
<body>
	<?php
		include('menubar.php');
		include('../model/databaseConnection.php');
		$query = "SELECT * FROM articles";
		$run = mysqli_query($connect , $query);
	?>

	<form method="POST" action="">
				<span><h2>Titre De Votre Article</h2></span>
				<textarea class="tinymce" name="givenArticleTitle"> </textarea>

				<span><h2>Your Article</h2></span>
				<textarea class="tinymce" name="givenArticleParagraph"></textarea>
			
				<input id="createArticleSubmitButton" type="submit" name="updateArticleSubmitButton">
	</form>

<script type="text/javascript" src="../view/tinymce/js/jquery.min.js"></script>
<script type="text/javascript" src="../view/tinymce/plugin/tinymce/tinymce.min.js"></script>
<script type="text/javascript" src="../view/tinymce/plugin/tinymce/init-tinymce.js"></script>


</body>
</html>