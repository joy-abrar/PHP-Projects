<?php
	include('../../model/databaseConnection.php');
?>

<?php
	if (isset($_POST['editArt'])) 
	{
		header("location:../../view/editArticle/editArticle.php");	
	}
?>



