
<head>
	<link rel="stylesheet" type="text/css" href="public/css/style.css">
</head>
	<div id="menuParam">
		
		<div id="indexTitle">
			<a href="../../index.php?action=accueil" id="indexTitleParam">JEAN FORTEROCHE</a>
		</div>

		<div id="navBlock">
		<a href="../../index.php?action=accueil" class="navParam" id="accueil">ACCUEIL</a>
		<a href="../../index.php?action=biographie" class="navParam" id="biographie">BIOGRAPHIE</a>
		<a href="../../index.php?action=billets" class="navParam" id="billetSimple">BILLETS SIMPLE</a>
		<a href="../../index.php?action=contact" class="navParam" id="contact">CONTACT</a>
		</div>
	</div>

