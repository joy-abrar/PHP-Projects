<?php
	include('templates/aboutus/menubar.php');
	include('templates/aboutus/about.php');
	include('templates/aboutus/footer.php');
?>