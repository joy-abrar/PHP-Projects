<?php
	include('menubar.php');
?>	

<center><h3 id="contactPageTitle">CONTACTEZ-NOUS EN REMPLISSANT CE FORMULAIRE</h3></center>
<form method="POST" action="index.php?action=postThisMessage">
	<center id="messageBoxParam">
		<h4>Votre Adresse Mail</h4>
		<input type="email" name="mail" id="messageBoxUsernameParam">

		<h4>Votre Message</h4>
		<input type="text" name="userMessage" id="messageBoxCommentParam">
	
		<center><input type="submit" name="postMessage" id="messageBoxValidButtonParam" value="POSTER"></center>
	</center>
</form>

<?php
	include('footer.php');
?>