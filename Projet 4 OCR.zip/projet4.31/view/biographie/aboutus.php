<?php

	include('../templates/menubar.php');
	include('../templates/about.php');
	include('../templates/footer.php');

?>